//
//  PermissionAnimationApp.swift
//  PermissionAnimation
//
//  Created by Balaji Venkatesh on 25/02/26.
//

import SwiftUI

@main
struct PermissionAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
