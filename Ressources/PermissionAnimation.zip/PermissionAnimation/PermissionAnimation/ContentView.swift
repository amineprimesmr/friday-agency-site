//
//  ContentView.swift
//  PermissionAnimation
//
//  Created by Balaji Venkatesh on 25/02/26.
//

import SwiftUI

struct ContentView: View {
    @State private var buttons: PermissionOnBoarding.Buttons = .two
    @State private var activeTap: PermissionOnBoarding.ActiveTap = .two
    @State private var showView: Bool = false
    var body: some View {
        NavigationStack {
            List {
                Section("Button's") {
                    Picker("", selection: $buttons) {
                        Text("Two")
                            .tag(PermissionOnBoarding.Buttons.two)
                        
                        Text("Three")
                            .tag(PermissionOnBoarding.Buttons.three)
                    }
                    .pickerStyle(.segmented)
                }
                
                Section("Active Tap") {
                    Picker("", selection: $activeTap) {
                        Text("One")
                            .tag(PermissionOnBoarding.ActiveTap.one)
                        
                        Text("Two")
                            .tag(PermissionOnBoarding.ActiveTap.two)
                        
                        Text("Three")
                            .tag(PermissionOnBoarding.ActiveTap.three)
                    }
                    .pickerStyle(.segmented)
                }
                
                Section("Demo") {
                    Button("Show View") {
                        showView.toggle()
                    }
                }
            }
            .navigationTitle("Permission Animation")
        }
        .fullScreenCover(isPresented: $showView) {
            let isThreeButtons = buttons == .three
            let title = isThreeButtons ? "Stay Local with\nLocation Access" : "Stay Connected with\nPush Notifications"
            let description = isThreeButtons ? "We will use your location to provide you with\npersonalized content and nearby recommendations" : "We will send you push notifications to keep\nyou updated on the latest news and updates."
            PermissionOnBoarding(
                config: .init(
                    iPhoneTint: .gray,
                    buttonTint: .blue,
                    initialDelay: 0.5,
                    title: title,
                    description: description,
                    alertButtons: buttons,
                    activeTap: activeTap,
                    primaryTitle: "Continue",
                    primaryAction: {
                        
                    },
                    secondaryTitle: "Ask me Later",
                    secondaryAction: {
                        showView = false
                    }
                )
            )
        }
    }
}

#Preview {
    ContentView()
}
