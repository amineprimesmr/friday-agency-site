//
//  ContentView.swift
//  ThreadsDismiss
//
//  Created by Balaji Venkatesh on 19/03/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                LazyVStack(spacing: 12) {
                    NavigationLink {
                        ThreadsView()
                    } label: {
                        MasterPostView()
                            .foregroundStyle(Color.primary)
                    }
                }
            }
            .navigationTitle("Home")
        }
    }
}

struct ThreadsView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ScrollView(.vertical) {
            VStack(spacing: 0) {
                MasterPostView()

                Divider()
                    .padding(.horizontal, 15)

                HStack {
                    Text("Replies")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 15)
                .padding(.vertical, 12)

                VStack(spacing: 12) {
                    CommentRow(userName: "Jenna", isTwoLine: true)
                    CommentRow(userName: "Emily")
                    CommentRow(userName: "Grace", isTwoLine: true)
                    CommentRow(userName: "Kaviya")
                    CommentRow(userName: "Sherry", isTwoLine: true)
                }
            }
        }
        .swipeUpToDismiss(120, onDismiss: {
            dismiss()
        })
        .navigationTitle("Thread")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct MasterPostView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Circle()
                    .fill(.fill)
                    .frame(width: 45, height: 45)

                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 4) {
                        Text("iJustine")
                            .font(.subheadline)
                            .fontWeight(.bold)
                        
                        Image(systemName: "checkmark.seal.fill")
                            .font(.caption)
                            .foregroundStyle(.blue)
                    }
                    
                    Text("@ijustine")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer(minLength: 0)

                Text("2h")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.")
                .font(.body)
                .lineSpacing(4)
                .multilineTextAlignment(.leading)

            HStack(spacing: 16) {
                Text("101 replies")
                Text("128 reposts")
                Text("10.1K likes")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(.top, 4)

            Divider()

            HStack(spacing: 0) {
                Group {
                    Image(systemName: "bubble.right")
                    Image(systemName: "arrow.2.squarepath")
                    Image(systemName: "heart")
                    Image(systemName: "square.and.arrow.up")
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.vertical, 4)
        }
        .padding(15)
    }
}

struct CommentRow: View {
    var userName: String
    var isTwoLine: Bool = false
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Circle()
                .fill(.fill)
                .frame(width: 35, height: 35)

            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(userName)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    
                    Text("@\(userName)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    Spacer(minLength: 0)
                    
                    Text("1h")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Text("Contrary to popular belief, Lorem Ipsum is not simply random text.\(isTwoLine ? "It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old." : "")")
                    .font(.subheadline)
                    .lineSpacing(3)
                    .multilineTextAlignment(.leading)

                HStack(spacing: 20) {
                    Image(systemName: "bubble.right")
                    Image(systemName: "arrow.2.squarepath")
                    Image(systemName: "heart")
                    Image(systemName: "square.and.arrow.up")
                }
                .padding(.top, 2)
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 10)
    }
}

#Preview {
    ContentView()
}
