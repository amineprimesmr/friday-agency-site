//
//  ThreadsDismissApp.swift
//  ThreadsDismiss
//
//  Created by Balaji Venkatesh on 19/03/26.
//

import SwiftUI

@main
struct ThreadsDismissApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
