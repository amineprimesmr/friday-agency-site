//
//  DeleteButtonApp.swift
//  DeleteButton
//
//  Created by Balaji Venkatesh on 31/10/25.
//

import SwiftUI

@main
struct DeleteButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
