//
//  AnimatedDeleteButton.swift
//  DeleteButton
//
//  Created by Balaji Venkatesh on 31/10/25.
//

import SwiftUI

struct AnimatedButtonCornerRadius {
    var source: CGFloat = 30
    var destination: CGFloat = 45
}

struct CustomAction {
    var title: String
    var background: Color
    var foreground: Color
}

fileprivate struct AnimatedButtonProperties {
    var sourceLocation: CGRect = .zero
    var sourceView: UIImage?
    var hideSource: Bool = false
    var animate: Bool = false
    var showDeleteView: Bool = false
}

struct AnimatedDeleteButton<Content: View, Label: View>: View {
    var cornerRadius: AnimatedButtonCornerRadius = .init()
    var customAction: CustomAction?
    @ViewBuilder var content: Content
    @ViewBuilder var label: Label
    var action: (_ isCancelled: Bool) -> ()
    @State fileprivate var properties: AnimatedButtonProperties = .init()
    @Environment(\.displayScale) private var displayScale: CGFloat
    var body: some View {
        Button {
            let renderer = ImageRenderer(content:
                label
                    .frame(
                        width: properties.sourceLocation.width,
                        height: properties.sourceLocation.height
                    )
                    .clipShape(.rect(cornerRadius: cornerRadius.source))
            )
            renderer.scale = displayScale
            properties.sourceView = renderer.uiImage
            
            /// Going to show full-scree-cover without animation!
            noAnimation {
                properties.showDeleteView = true
            }
        } label: {
            label
                .clipShape(.rect(cornerRadius: cornerRadius.source))
                .contentShape(.rect(cornerRadius: cornerRadius.source))
                /// Hiding Source View
                .opacity(properties.showDeleteView ? 0 : 1)
        }
        .onGeometryChange(for: CGRect.self, of: {
            $0.frame(in: .global)
        }, action: { newValue in
            properties.sourceLocation = newValue
        })
        .buttonStyle(.plain)
        /// Going to use Full-screen-cover for the animation so that the source view can be added anywhere deep inside and still the animation will work!
        .fullScreenCover(isPresented: $properties.showDeleteView) {
            DeleteButtonView(customAction: customAction, cornerRadius: cornerRadius, properties: $properties) {
                content
            } action: { isUserCancelled in
                action(isUserCancelled)
            }
            .ignoresSafeArea()
            .presentationBackground(.clear)
            .persistentSystemOverlays(.hidden)
        }
    }
}

fileprivate struct DeleteButtonView<Content: View>: View {
    var customAction: CustomAction?
    var cornerRadius: AnimatedButtonCornerRadius
    @Binding fileprivate var properties: AnimatedButtonProperties
    @ViewBuilder var content: Content
    var action: (_ isUserCancelled: Bool) -> ()
    var body: some View {
        let animate = properties.animate
        let hideSource = properties.hideSource
        let sourceLocation = properties.sourceLocation
        
        ZStack(alignment: .bottom) {
            Rectangle()
                .fill(.black.opacity(animate ? 0.4 : 0))
            
            /// Content View
            VStack(spacing: 10) {
                content
                
                ActionButtons()
            }
            .allowsHitTesting(animate)
            .padding(20)
            .compositingGroup()
            .geometryGroup()
            .background(.background, in: clipShape)
            .blur(radius: animate ? 0 : 10)
            /// If you dont want the fade in/fade out effect (Use this method!)
            .opacity(animate ? 1 : 0)
            /// Replace Opacity with this
            //.opacity(properties.showDeleteView ? 1 : 0)
            // Replace .background with .overlay
            .background {
                GeometryReader {
                    let size = $0.size
                    
                    if let sourceView = properties.sourceView {
                        Image(uiImage: sourceView)
                            .resizable()
                            .frame(
                                width: animate ? size.width : sourceLocation.width,
                                height: animate ? size.height : sourceLocation.height,
                            )
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .blur(radius: hideSource ? 10 : 0)
                            .opacity(hideSource ? 0 : 1)
                    }
                }
            }
            /// Using mask to change view size, instead of using frame, so that the content won't have any text clipping or wrapping and will look more clean!
            .mask {
                clipShape
                    .frame(
                        width: animate ? nil : sourceLocation.width,
                        height: animate ? nil : sourceLocation.height
                    )
            }
            .padding(.horizontal, 10)
            /// Using Visual Effect to animate from source to destination
            .visualEffect { content, proxy in
                content
                    .offset(
                        x: animate ? 0 : sourceLocation.midX - (proxy.size.width / 2),
                        y: animate ? -10 : sourceLocation.midY - (proxy.size.height / 2)
                    )
            }
            /// Since coordination system starts from top-left!
            .frame(
                maxWidth: .infinity,
                maxHeight: .infinity,
                alignment: animate ? .bottom : .topLeading
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            withAnimation(animation) {
                properties.animate = true
            }
            
            /// Some times calling two withAnimations leading to animate only one, thus let's solve this by putting another one inside the Task!
            Task {
                withAnimation(sourceAnimation) {
                    properties.hideSource = true
                }
            }
        }
    }
    
    /// Action Buttons
    @ViewBuilder
    private func ActionButtons() -> some View {
        HStack(spacing: 6) {
            Button {
                dismiss(false)
             } label: {
                 Text("Cancel")
                     .foregroundStyle(Color.primary)
                     .frame(maxWidth: .infinity)
                     .padding(.vertical, 11)
                     .background(.gray.opacity(0.3))
                     .clipShape(.capsule)
             }
             
             Button {
                 dismiss(true)
             } label: {
                 if let customAction {
                     Text(customAction.title)
                         .foregroundStyle(customAction.foreground)
                         .frame(maxWidth: .infinity)
                         .padding(.vertical, 11)
                         .background(customAction.background.gradient)
                         .clipShape(.capsule)
                 } else {
                     Text("Delete")
                         .foregroundStyle(.white)
                         .frame(maxWidth: .infinity)
                         .padding(.vertical, 11)
                         .background(.red.gradient)
                         .clipShape(.capsule)
                 }
             }
        }
        .fontWeight(.medium)
    }
    
    func dismiss(_ status: Bool) {
        withAnimation(animation, completionCriteria: .removed) {
            properties.animate = false
        } completion: {
            noAnimation {
                properties.sourceView = nil
                properties.showDeleteView = false
            }
            
            /// You can place this before the animation completion, but I'm placing it after, so it's your wish!
            action(status)
        }
        
        Task {
            withAnimation(sourceAnimation.delay(0.08)) {
                properties.hideSource = false
            }
        }
    }
    
    var clipShape: AnyShape {
        let radius = properties.animate ? cornerRadius.destination : cornerRadius.source
        
        return .init(.rect(cornerRadius: radius))
    }
    
    /// Change animations according to your own needs!
    var animation: Animation {
        .interpolatingSpring(duration: 0.3)
    }
    
    var sourceAnimation: Animation {
        .smooth(duration: 0.15, extraBounce: 0)
    }
}

#Preview {
    ContentView()
}

extension View {
    func noAnimation(_ content: @escaping () -> ()) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        
        withTransaction(transaction) {
            content()
        }
    }
}
