//
//  ContentView.swift
//  AWCAnimation
//
//  Created by Balaji Venkatesh on 28/04/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
