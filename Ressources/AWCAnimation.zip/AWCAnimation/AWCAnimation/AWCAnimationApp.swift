//
//  AWCAnimationApp.swift
//  AWCAnimation
//
//  Created by Balaji Venkatesh on 28/04/26.
//

import SwiftUI

@main
struct AWCAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
