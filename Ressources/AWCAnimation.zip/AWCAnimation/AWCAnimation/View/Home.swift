//
//  Home.swift
//  AWCAnimation
//
//  Created by Balaji Venkatesh on 28/04/26.
//

import SwiftUI

struct Home: View {
    @State private var selectedCard: Card?
    @State private var info: Info = .init()
    @Environment(\.colorScheme) private var colorScheme
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                VStack(spacing: -150) {
                    ForEach(cards) { card in
                        CardView(card)
                    }
                }
            }
            .scrollIndicators(.hidden)
            .safeAreaPadding(15)
            .scrollDisabled(isCardSelected)
            .navigationTitle(isNavgationTitleHidden ? "" : "Wallet")
            .toolbarTitleDisplayMode(.inlineLarge)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if isCardSelected {
                        Button("Close", systemImage: "xmark") {
                            withAnimation(animation) {
                                selectedCard = nil
                            }
                        }
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button(isCardSelected ? "Edit" : "Add Card", systemImage: isCardSelected ? "creditcard.and.numbers" : "plus") {
                        
                    }
                }
                
                if !isCardSelected {
                    ToolbarSpacer(.fixed, placement: .topBarTrailing)
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    if !isCardSelected {
                        Button("Search", systemImage: "magnifyingglass") {
                            
                        }
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Options", systemImage: "ellipsis") {
                        
                    }
                }
            }
            .onScrollGeometryChange(for: CGFloat.self) {
                $0.contentOffset.y + $0.contentInsets.top
            } action: { oldValue, newValue in
                info.scrollOffset = newValue
            }
            .onGeometryChange(for: CGFloat.self) {
                $0.frame(in: .global).minY
            } action: { newValue in
                info.minY = newValue - info.safeArea.top
            }
            .background(.gray.opacity(0.25))
        }
        .sheet(item: $selectedCard) { card in
            let spacing: CGFloat = 20
            let isSafeAreaiPhone = info.safeArea.bottom > 0
            let minSheetHeight: CGFloat = info.containerSize.height - info.minY - (220 + spacing)
            let maxSheetHeight: CGFloat = info.containerSize.height - info.minY + (isSafeAreaiPhone ? 15 : 10)
            
            TransactionsSheetView(card: card)
                .presentationDetents([.height(minSheetHeight), .height(maxSheetHeight)])
                .presentationBackgroundInteraction(.enabled(upThrough: .height(maxSheetHeight)))
                .interactiveDismissDisabled()
                .presentationBackground(schemeBackground)
        }
        .onGeometryChange(for: CGSize.self) {
            $0.size
        } action: { newValue in
            info.containerSize = newValue
        }
        .onGeometryChange(for: EdgeInsets.self) {
            $0.safeAreaInsets
        } action: { newValue in
            info.safeArea = newValue
        }
    }
    
    /// Card View
    @ViewBuilder
    func CardView(_ card: Card) -> some View {
        let isCurrent = card.id == selectedCardID
        let currentIndex = cards.firstIndex(where: { $0.id == card.id }) ?? 0
        let selectedCardIndex = cards.firstIndex(where: { $0.id == selectedCardID }) ?? 0
        
        Rectangle()
            .foregroundStyle(.clear)
            .overlay {
                Image(card.cardBackground)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            }
            .overlay {
                VStack {
                    HStack {
                        Text(card.cardCategory)
                            .monospaced()
                            .fontWeight(.semibold)
                        
                        Spacer(minLength: 0)
                        
//                        Image(card.cardType)
//                            .resizable()
//                            .renderingMode(card.cardType == "MC" ? .original : .template)
//                            .aspectRatio(contentMode: .fit)
//                            .frame(height: 25)
                    }
                    .foregroundStyle(.white)
                    
                    Spacer(minLength: 0)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(card.title)
                            .monospaced()
                        
                        Text("**** 1234")
                            .monospaced()
                    }
                    .foregroundStyle(.white)
                    .fontWeight(.medium)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(20)
            }
            .clipShape(.rect(cornerRadius: 20))
            .frame(height: 220)
            .contentShape(.rect)
            .onTapGesture {
                withAnimation(animation) {
                    selectedCard = card
                }
            }
            /// Card Animation Using Visual Effett API
            .visualEffect { [info, isCardSelected] content, proxy in
                let rect = proxy.frame(in: .scrollView)
                let bounds = info.containerSize
                
                /// Top cards stacks at top
                /// Bottom cards pushes bottom to the screen
                let pushOffset = selectedCardIndex < currentIndex ? (bounds.height - rect.minY) : -rect.minY
                let scale = selectedCardIndex < currentIndex ? 1 : 0.95
                
                return content
                    /// A little scale animation for top cards!
                    .scaleEffect(isCardSelected ? (isCurrent ? 1 : scale) : 1, anchor: .top)
                    .offset(y: isCardSelected ? pushOffset : 0)
            }
            .allowsHitTesting(isCardSelected ? isCurrent : true)
    }
    
    var isNavgationTitleHidden: Bool {
        return info.scrollOffset > 1 || isCardSelected
    }
    
    var isCardSelected: Bool {
        return selectedCardID != nil
    }
    
    var selectedCardID: String? {
        return selectedCard?.id
    }
    
    var schemeBackground: Color {
        return colorScheme == .dark ? .black : .white
    }
    
    struct Info {
        var scrollOffset: CGFloat = 0
        var containerSize: CGSize = .zero
        var safeArea: EdgeInsets = .init()
        var minY: CGFloat = 0
    }
    
    var animation: Animation = .interactiveSpring(response: 0.55, dampingFraction: 0.8)
}

struct TransactionsSheetView: View {
    var card: Card
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                LazyVStack(alignment: .leading, spacing: 25) {
                    Text("Recent Transactions")
                        .font(.title2.bold())
                        .foregroundStyle(.black)
                    
                    ForEach(1...50, id: \.self) { _ in
                        HStack(alignment: .top, spacing: 10) {
                            RoundedRectangle(cornerRadius: 10)
                                .frame(width: 45, height: 45)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Rectangle()
                                    .frame(height: 18)
                                
                                Rectangle()
                                    .frame(width: 100, height: 18)
                            }
                            
                            HStack(spacing: 4) {
                                Text("$")
                                    .fontWeight(.bold)
                                
                                Rectangle()
                                    .frame(width: 50, height: 15)
                                
                                Image(systemName: "chevron.right")
                                    .font(.caption)
                            }
                        }
                        .foregroundStyle(.fill)
                        .listRowSeparator(.hidden)
                    }
                }
                .padding(20)
                .padding(.top, 20)
            }
            .toolbarVisibility(.hidden, for: .navigationBar)
        }
    }
}

#Preview {
    ContentView()
}
