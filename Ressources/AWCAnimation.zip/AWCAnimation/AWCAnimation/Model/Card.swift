//
//  Card.swift
//  AWCAnimation
//
//  Created by Balaji Venkatesh on 28/04/26.
//

import SwiftUI

struct Card: Identifiable {
    var id: String = UUID().uuidString
    var cardBackground: String
    var title: String
    var cardCategory: String
    var cardType: String
}

/// Dummy Mock Data
let cards: [Card] = [
    .init(cardBackground: "Card 1", title: "Grace", cardCategory: "DEBIT", cardType: "Visa"),
    .init(cardBackground: "Card 3", title: "Ashley", cardCategory: "DEBIT", cardType: "MC"),
    .init(cardBackground: "Card 4", title: "Diana", cardCategory: "Apple Cash", cardType: "Apple"),
    .init(cardBackground: "Card 2", title: "iJustine", cardCategory: "CREDIT", cardType: "Visa"),
]
