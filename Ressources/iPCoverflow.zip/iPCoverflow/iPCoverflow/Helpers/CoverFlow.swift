//
//  CoverFlow.swift
//  iPCoverflow
//
//  Created by Balaji Venkatesh on 05/05/26.
//

import SwiftUI

struct CoverFlowConfig {
    var cardWidth: CGFloat
    var rotation: CGFloat = 58
    var offsetFactor: CGFloat = 1.4
    var activeElevation: CGFloat = 0
    /// Reflection Properties
    var reflectionGap: CGFloat = 0.5
    var reflectionFade: CGFloat = 4
    var reflectionDim: CGFloat = 0.8
}

struct CoverFlow<Content: View>: View {
    var config: CoverFlowConfig
    @Binding var activeIndex: Int?
    @ViewBuilder var content: Content
    var body: some View {
        GeometryReader {
            let containerSize = $0.size
            let currentIndex = activeIndex ?? 0
            
            ScrollView(.horizontal) {
                HStack(spacing: 0) {
                    Group(subviews: content) { collection in
                        ForEach(collection.indices, id: \.self) { index in
                            let subview = collection[index]
                            let zIndex = currentIndex > index ? Double(index) : Double(-index)
                            
                            subview
                                .frame(width: config.cardWidth, height: containerSize.height)
                                /// Rotation and offset handling via visualEffect modifier!
                                .visualEffect { [config] content, proxy in
                                    let values = retriveLayoutAdjustmentValues(proxy, config: config)
                                    
                                    return content
                                        .layerEffect(
                                            ShaderLibrary.coverflowReflection(
                                                .float(proxy.size.height),
                                                .float(config.reflectionGap),
                                                .float(config.reflectionFade),
                                                .float(config.reflectionDim)
                                            ),
                                            maxSampleOffset: proxy.size
                                        )
                                        .rotation3DEffect(
                                            .init(degrees: values.rotation),
                                            axis: (x: 0, y: 1, z: 0),
                                            anchor: values.anchor,
                                            anchorZ: values.anchorZ,
                                            perspective: 1
                                        )
                                        .offset(x: values.offset)
                                }
                                .zIndex(currentIndex == index ? 1000 : zIndex)
                        }
                    }
                }
                .scrollTargetLayout()
            }
            /// Start and end at center
            .safeAreaPadding(.horizontal, (containerSize.width - config.cardWidth) / 2)
            .scrollPosition(id: $activeIndex, anchor: .center)
            .scrollTargetBehavior(.viewAligned)
            .scrollClipDisabled()
        }
    }
    
    nonisolated
    private func retriveLayoutAdjustmentValues(
        _ proxy: GeometryProxy,
        config: CoverFlowConfig
    ) -> (rotation: CGFloat, anchor: UnitPoint, anchorZ: CGFloat, offset: CGFloat) {
        let minX = proxy.frame(in: .scrollView(axis: .horizontal)).minX
        let progress = minX / config.cardWidth
        /// Capping Progress between -1 to 1
        let cappedProgress = max(-1, min(1, progress))
        
        let rotation = -cappedProgress * config.rotation
        let offset = -progress * (config.cardWidth / config.offsetFactor)
        let anchor: UnitPoint = cappedProgress < 0 ? .leading : .trailing
        let anchorZ = abs(cappedProgress) * config.activeElevation
        
        return (rotation, anchor, anchorZ, offset)
    }
}

#Preview {
    ContentView()
}
