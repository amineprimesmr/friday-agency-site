//
//  iPCoverflowApp.swift
//  iPCoverflow
//
//  Created by Balaji Venkatesh on 05/05/26.
//

import SwiftUI

@main
struct iPCoverflowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
