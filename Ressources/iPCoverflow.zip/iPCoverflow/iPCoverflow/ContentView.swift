//
//  ContentView.swift
//  iPCoverflow
//
//  Created by Balaji Venkatesh on 05/05/26.
//

import SwiftUI

struct ContentView: View {
    @State private var activeIndex: Int?
    @State private var elevation: CGFloat = 0
    
    let colors: [Color] = [.red, .blue, .green, .yellow, .purple, .indigo, .mint, .brown, .orange, .cyan]
    var body: some View {
        let activeColor = colors[activeIndex ?? 0]
        
        VStack {
            CoverFlow(config: .init(cardWidth: 160, activeElevation: elevation), activeIndex: $activeIndex) {
                ForEach(colors, id: \.self) { color in
                    Rectangle()
                        .fill(color.gradient)
                }
            }
            .frame(height: 220)
            .scrollIndicators(.hidden)
            .overlay(alignment: .top) {
                VStack(spacing: 2) {
                    Text("Current Color")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                    
                    Text(String(describing: activeColor))
                        .textCase(.uppercase)
                        .fontWeight(.semibold)
                }
                .offset(y: -70)
            }
        }
        .frame(maxHeight: .infinity)
        .overlay(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Active Card Focus")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                Slider(value: $elevation, in: 0...60)
            }
            .padding(.horizontal, 40)
            .padding(.bottom, 10)
        }
        .background {
            Rectangle()
                .fill(
                    LinearGradient(colors: [
                        activeColor, activeColor.opacity(0.5),
                        .clear, .clear, .clear
                    ], startPoint: .top, endPoint: .bottom)
                )
                .ignoresSafeArea()
                .animation(.interpolatingSpring(duration: 0.3, bounce: 0, initialVelocity: 0), value: activeIndex)
        }
        .preferredColorScheme(.dark)
    }
}

#Preview {
    ContentView()
}
