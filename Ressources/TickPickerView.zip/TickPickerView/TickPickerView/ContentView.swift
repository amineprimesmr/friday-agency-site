//
//  ContentView.swift
//  TickPickerView
//
//  Created by Balaji Venkatesh on 21/12/25.
//

import SwiftUI

struct ContentView: View {
    @State private var selection: Int = 5
    @State private var alignment: TickConfig.Alignment = .bottom
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("", selection: $alignment) {
                    ForEach(TickConfig.Alignment.allCases, id: \.rawValue) {
                        Text($0.rawValue)
                            .tag($0)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 15)
                .padding(.bottom, 30)
                
                Circle()
                    .fill(.primary.opacity(0.2))
                    .frame(width: 8, height: 8)
                
                TickPicker(count: 100, config: config, selection: $selection)
                
                HStack(alignment: .bottom, spacing: 2) {
                    Text("\(currentCentimeters)")
                    Text("CM")
                        .font(.caption)
                }
                .monospaced()
                .fontWeight(.semibold)
            }
            .navigationTitle("Tick Picker")
        }
    }
    
    var currentCentimeters: Int {
        50 + selection
    }
    
    var config: TickConfig {
        return .init(
            tickWidth: 2,
            alignment: alignment
        )
    }
}

#Preview {
    ContentView()
}
