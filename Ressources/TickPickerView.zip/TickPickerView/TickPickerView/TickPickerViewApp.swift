//
//  TickPickerViewApp.swift
//  TickPickerView
//
//  Created by Balaji Venkatesh on 21/12/25.
//

import SwiftUI

@main
struct TickPickerViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
