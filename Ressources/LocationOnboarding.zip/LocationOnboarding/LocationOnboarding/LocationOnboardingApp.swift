//
//  LocationOnboardingApp.swift
//  LocationOnboarding
//
//  Created by Balaji Venkatesh on 11/11/25.
//

import SwiftUI

@main
struct LocationOnboardingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
