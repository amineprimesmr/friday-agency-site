//
//  ContentView.swift
//  LocationOnboarding
//
//  Created by Balaji Venkatesh on 11/11/25.
//

import SwiftUI
import MapKit

extension MKCoordinateRegion {
    static var applePark: MKCoordinateRegion {
        .init(
            center: .init(latitude: 37.3346, longitude: -122.0090),
            latitudinalMeters: 1000,
            longitudinalMeters: 1000
        )
    }
}

struct ContentView: View {
    let config = LocationPermissionViewConfig(appName: "Apple Music")
    @State private var show: Bool = false
    var body: some View {
        NavigationStack {
            List {
                Section("Usage") {
                    Text(
                    """
                    **.locationPermissionView** {
                      // Your Screen View!
                    } **authorizationDidChange:** {
                        
                    } **askLater:** {
                        
                    }
                    """
                    )
                    .font(.callout)
                    .monospaced()
                }
                
                Section("Demo") {
                    Button("Show Permission View") {
                        show.toggle()
                    }
                }
            }
            .navigationTitle("Location OnBoarding")
        }
        .locationPermissionFullScreenCover(isPresented: $show, config: config) {
            /// Your Screen View!
//            Map(initialPosition: .region(.applePark))
//                .mapStyle(.standard(
//                    elevation: .flat,
//                    emphasis: .muted,
//                    pointsOfInterest: .excludingAll,
//                    showsTraffic: false
//                ))
            
            /// Or Image View Like This!
            /// Make sure to have both the dark and light versions!
            Image("MapImage")
                .resizable()
                .aspectRatio(contentMode: .fill)
        } authorizationDidChange: { status in
            print(status)
        } askLater: {
            print("Ask Later")
        }
    }
}

#Preview {
    ContentView()
}
