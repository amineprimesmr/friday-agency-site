//
//  Toast.swift
//  LGToasts
//
//  Created by Balaji Venkatesh on 18/04/26.
//

import SwiftUI

struct ToastRootView<Content: View>: View {
    @ViewBuilder var content: Content
    /// View Properties
    @State private var activeToast: Toast?
    @State private var toastDismissWorkItem: DispatchWorkItem?
    var body: some View {
        content
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .overlay(alignment: .bottom) {
                GlassEffectContainer(spacing: 10) {
                    if let activeToast {
                        ToastView(activeToast)
                    }
                }
                .opacity(activeToast == nil ? 0 : 1)
            }
            .environment(\.showToast) { toast in
                withAnimation(animation.logicallyComplete(after: 0.17), completionCriteria: .logicallyComplete) {
                    /// Removing old toast to show the updated one!
                    if activeToast != nil {
                        activeToast = nil
                    }
                } completion: {
                    toastDismissWorkItem?.cancel()
                    
                    withAnimation(animation) {
                        activeToast = toast
                    }
                    
                    toastDismissWorkItem = .init(block: dismiss)
                    /// Limiting the minimum duration to 1!
                    let duration = max(toast.duration, 1)
                    if let toastDismissWorkItem {
                        DispatchQueue.main.asyncAfter(
                            deadline: .now() + duration,
                            execute: toastDismissWorkItem
                        )
                    }
                }
            }
            .environment(\.dismissToast) {
                dismiss()
            }
    }
    
    @ViewBuilder
    private func ToastView(_ toast: Toast) -> some View {
        HStack(spacing: 10) {
            if let symbol = toast.symbol {
                Image(systemName: symbol)
                    .font(.title3)
                    .foregroundStyle(Color.primary)
                    .transition(.identity)
            }
            
            Text(toast.title)
                .font(.body)
                .lineLimit(1)
            
            Spacer(minLength: 0)
            
            if let actionTitle = toast.actionTitle, let action = toast.action {
                Button {
                    /// If true, then dismiss the toast!
                    if action() {
                        dismiss()
                    }
                } label: {
                    Text(actionTitle)
                        .foregroundStyle(toast.actionTint)
                }
                .transition(.identity)
            }
        }
        .padding(.horizontal, 18)
        .frame(height: 50)
        .clipShape(.capsule)
        .contentShape(.capsule)
        .glassEffect(.regular, in: .capsule)
        .padding(.horizontal, 15)
        /// Placement offset
        .offset(y: toast.placementOffset)
        .gesture(
            DragGesture()
                .onEnded { value in
                    let endTranslation = value.translation.height
                    if endTranslation > 30 {
                        dismiss()
                    }
                }
        )
        /// Offset Transition
        .transition(.offset(y: toast.transitionOffset))
    }
    
    private func dismiss() {
        withAnimation(animation) {
            activeToast = nil
        }
        
        toastDismissWorkItem?.cancel()
    }
    
    private let animation: Animation = .interpolatingSpring(duration: 0.35, bounce: 0, initialVelocity: 0)
}

struct Toast: Identifiable {
    private(set) var id: String = UUID().uuidString
    /// Toast Properties!
    var title: String
    var duration: CGFloat
    var placementOffset: CGFloat
    var transitionOffset: CGFloat = 100
    var symbol: String? = nil
    var actionTitle: String? = nil
    var actionTint: Color = .accentColor
    var action: (() -> Bool)? = nil
}

extension EnvironmentValues {
    @Entry var showToast: (Toast) -> () = { _ in }
    @Entry var dismissToast: () -> () = {  }
}

#Preview {
    ContentView()
}
