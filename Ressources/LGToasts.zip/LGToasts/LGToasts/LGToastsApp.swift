//
//  LGToastsApp.swift
//  LGToasts
//
//  Created by Balaji Venkatesh on 18/04/26.
//

import SwiftUI

@main
struct LGToastsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
