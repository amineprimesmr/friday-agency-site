//
//  PositionalPadSliderApp.swift
//  PositionalPadSlider
//
//  Created by Balaji Venkatesh on 26/03/26.
//

import SwiftUI

@main
struct PositionalPadSliderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
