//
//  ContentView.swift
//  PositionalPadSlider
//
//  Created by Balaji Venkatesh on 26/03/26.
//

import SwiftUI

struct ContentView: View {
    @State private var position: CGPoint = .init(x: 0.5, y: 0.5)
    @Environment(\.colorScheme) private var colorScheme
    var body: some View {
        VStack(spacing: 15) {
            VStack(spacing: 10) {
                Image(.pic)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(50)
                    .shadow(
                        color: .black.opacity(0.3),
                        radius: 10,
                        x: ((position.x * 2) - 1) * 30,
                        y: ((position.y * 2) - 1) * 30
                    )
                
                if #available(iOS 26, macOS 26, *) {
                    HStack(spacing: 6) {
                        Text("PositionX")
                            .foregroundStyle(.gray)
                        
                        Text(String(format: "%.1f", position.x))
                        
                        Text("PositionY")
                            .foregroundStyle(.gray)
                            .padding(.leading, 5)
                        
                        Text(String(format: "%.1f", position.y))
                    }
                    .fontWeight(.medium)
                    .font(.caption)
                    .padding(10)
                    .glassEffect()
                    .offset(y: -10)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            let tint: Color = colorScheme != .dark ? .white : .black
            PhotosStylePositionPad(config: .init(tint: tint), position: $position)
                .padding(20)
                .background {
                    LinearGradient(colors: [
                        .primary, .primary.opacity(0.7)
                    ], startPoint: .top, endPoint: .bottom)
                    .clipShape(.rect(cornerRadius: 30))
                }
        }
    }
}

#Preview {
    ContentView()
}
