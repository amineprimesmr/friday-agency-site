//
//  MorphingTabBarEffectApp.swift
//  MorphingTabBarEffect
//
//  Created by Balaji Venkatesh on 15/02/26.
//

import SwiftUI

@main
struct MorphingTabBarEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
