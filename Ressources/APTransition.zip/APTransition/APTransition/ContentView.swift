//
//  ContentView.swift
//  APTransition
//
//  Created by Balaji Venkatesh on 07/04/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack {
                AppStoreTransition { isExpanded, dismiss in
                    Rectangle()
                        .foregroundStyle(.clear)
                        .overlay {
                            Image(.pic)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                        }
                        .overlay(alignment: .bottom) {
                            HStack(spacing: 10) {
                                Image(systemName: "apple.logo")
                                    .font(.title2)
                                    .frame(width: 45, height: 45)
                                    .foregroundStyle(.black)
                                    .background(.white, in: .rect(cornerRadius: 12))
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("macOS 26 Tahoe")
                                        .font(.callout)
                                        .foregroundStyle(.white)
                                    
                                    Text("Experience Liquid Glass")
                                        .font(.caption)
                                        .foregroundStyle(.white.secondary)
                                }
                                .lineLimit(1)
                                
                                Spacer(minLength: 0)
                                
                                Button {
                                    
                                } label: {
                                    Text("GET")
                                        .font(.caption)
                                        .fontWeight(.medium)
                                        .foregroundStyle(.black)
                                        .padding(.horizontal, 5)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.white)
                            }
                            .padding(.horizontal, 20)
                            .padding(.top, 10)
                            .padding(.bottom, 15)
                            .background(.black.tertiary)
                        }
                } content: { safeArea, dismiss in
                    DetailView(safeArea: safeArea, dismiss: dismiss)
                }
                .frame(height: 415)
                
                Spacer()
            }
            .padding(.horizontal, 25)
            .padding(.vertical, 15)
            .navigationTitle("App Store Transition")
            .background(Color.black.opacity(0.06))
        }
    }
}

struct DetailView: View {
    var safeArea: EdgeInsets
    var dismiss: () -> ()
    var body: some View {
        LazyVStack(alignment: .leading, spacing: 15) {
            CustomSection(
                title: "New Menu Bar",
                description: "Navigate your Mac effortlessly with\na sleek, adaptive menu bar.",
                image: "SS1"
            )
            
            CustomSection(
                title: "Personalized Home Screen",
                description: "Make your Mac truly yours by\nadding and arranging widgets.",
                image: "SS2"
            )
            
            CustomSection(
                title: "All New Spotlight Search",
                description: "Find what you need instantly with\npowerful, intuitive search tools",
                image: "SS3"
            )
        }
        .padding(15)
        .padding(.bottom, safeArea.bottom)
    }
    
    @ViewBuilder
    func CustomSection(title: String, description: String, image: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.title3)
                .fontWeight(.medium)
            
            Text(description)
                .foregroundStyle(.secondary)
            
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .clipShape(.rect(cornerRadius: 5))
                .padding(.top, 10)
        }
    }
}

#Preview {
    ContentView()
}
