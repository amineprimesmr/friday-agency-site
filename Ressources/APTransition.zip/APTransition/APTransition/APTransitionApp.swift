//
//  APTransitionApp.swift
//  APTransition
//
//  Created by Balaji Venkatesh on 07/04/26.
//

import SwiftUI

@main
struct APTransitionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
