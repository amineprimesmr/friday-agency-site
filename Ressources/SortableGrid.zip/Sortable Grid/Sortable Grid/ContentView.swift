//
//  ContentView.swift
//  Sortable Grid
//
//  Created by Balaji Venkatesh on 28/01/26.
//

import SwiftUI

struct Item: Identifiable, SortableGridProtocol {
    var id: String = UUID().uuidString
    var color: Color
    var position: CGRect = .zero
}

struct ContentView: View {
    @State private var items: [Item] = [
        .init(color: .red),
        .init(color: .blue),
        .init(color: .green),
        .init(color: .yellow),
        .init(color: .purple),
        .init(color: .orange)
    ]
    @State private var count: Int = 2
    var body: some View {
        NavigationStack {
            GeometryReader {
                let size = $0.size
                
                SortableGridView(isScrollable: true, config: .init(count: count), items: $items) { item in
                    ItemView(item, size: size)
                } draggingPreview: { previewItem in
                    ItemView(previewItem, size: size)
                } onDraggingChange: { location, offset, isDragging in
                    
                }
                .safeAreaPadding(15)
                .safeAreaPadding(.top, 5)
                .navigationTitle("Sortable Grid")
                .toolbarTitleDisplayMode(.inlineLarge)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Stepper("", value: $count, in: 2...5, step: 1)
                            .labelsHidden()
                    }
                }
                .animation(.smooth(duration: 0.3, extraBounce: 0), value: count)
            }
        }
    }
    
    @ViewBuilder
    func ItemView(_ item: Item, size: CGSize) -> some View {
        RoundedRectangle(cornerRadius: CGFloat(6 - count) * 5)
            .fill(item.color.gradient)
            .frame(height: size.width / CGFloat(count))
    }
}

#Preview {
    ContentView()
}
