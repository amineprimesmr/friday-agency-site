//
//  SortableGridView.swift
//  Sortable Grid
//
//  Created by Balaji Venkatesh on 28/01/26.
//

import SwiftUI

protocol SortableGridProtocol: Identifiable {
    var position: CGRect { get set }
}

struct SortableGridView<Content: View, DraggingPreview: View, Data: RandomAccessCollection>: View where Data.Element: SortableGridProtocol, Data: MutableCollection, Data: RangeReplaceableCollection {
    
    /// I dont want this property to be dynamically updating, that's why @State added here!
    @State var isScrollable: Bool
    var config: SortableGridConfig
    @Binding var items: Data
    @ViewBuilder var content: (Data.Element) -> Content
    @ViewBuilder var draggingPreview: (Data.Element) -> DraggingPreview
    var onDraggingChange: (_ location: CGPoint, _ offset: CGSize, _ isDragging: Bool) -> ()
    /// View Properties
    @State private var isDragging: Bool = false
    @State private var draggingItem: Data.Element?
    @State private var draggingStartRect: CGRect?
    @State private var draggingOffset: CGSize = .zero
    @State private var swapLock: Bool = false
    
    var body: some View {
        Group {
            if isScrollable {
                ScrollView(.vertical) {
                    GridContent()
                }
            } else {
                GridContent()
            }
        }
        .overlay(alignment: .topLeading) {
            if let draggingItem, let draggingStartRect {
                draggingPreview(draggingItem)
                    .disabled(true)
                    .allowsHitTesting(false)
                    .frame(width: draggingStartRect.width, height: draggingStartRect.height)
                    .animation(.snappy(duration: 0.3, extraBounce: 0)) { content in
                        content
                            .scaleEffect(isDragging ? config.previewScale : 1)
                    }
                    .offset(x: draggingStartRect.minX, y: draggingStartRect.minY)
                    .offset(draggingOffset)
            }
        }
        /// Disabling Interaction while there is an active dragging item
        .allowsHitTesting(draggingItem == nil)
        .coordinateSpace(.named("SORTABLEGRID"))
    }
    
    @ViewBuilder
    private func GridContent() -> some View {
        let columns: [GridItem] = Array(repeating: GridItem(spacing: config.spacing), count: config.count)
        
        LazyVGrid(columns: columns, spacing: config.spacing) {
            ForEach($items) { $item in
                content(item)
                    .opacity(draggingItem?.id == item.id ? 0 : 1)
                    /// Optional!
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .onGeometryChange(for: CGRect.self) {
                        $0.frame(in: .named("SORTABLEGRID"))
                    } action: { newValue in
                        item.position = newValue
                    }
                    .gesture(
                        CustomLongPressGesture(onChanged: { location, offset in
                            if draggingItem == nil {
                                draggingItem = item
                                draggingStartRect = item.position
                                DispatchQueue.main.async {
                                    isDragging = true
                                }
                            }
                            
                            draggingOffset = offset
                            reorderData(location: location)
                            onDraggingChange(location, offset, true)
                        }, onEnd: {
                            onDraggingChange(.zero, .zero, false)
                            /// Helps to Update the position value when there is any pending!
                            DispatchQueue.main.async {
                                withAnimation(.snappy(duration: 0.3, extraBounce: 0), completionCriteria: .logicallyComplete) {
                                    isDragging = false
                                    draggingOffset = .zero
                                    /// If there is a change in the dragging items location, then we updating the start location property to reflect the changes
                                    if let sourceIndex = items.firstIndex(where: { $0.id == draggingItem?.id }) {
                                        draggingStartRect = items[sourceIndex].position
                                    }
                                } completion: {
                                    draggingItem = nil
                                    draggingStartRect = nil
                                }
                            }
                        })
                    )
            }
        }
    }
    
    private func reorderData(location: CGPoint) {
        /// Finding Source Index
        if let draggingItem,
           let sourceIndex = items.firstIndex(where: { $0.id == draggingItem.id }), !swapLock {
            /// Finding Destination Index
            let destIndex = items.firstIndex(where: {
                $0.position.contains(location)
            })
            
            guard let destIndex, destIndex != sourceIndex else { return }
            
            /// Swapping Items
            swapLock = true
            withAnimation(.snappy(duration: 0.25, extraBounce: 0)) {
                let item = items.remove(at: sourceIndex)
                items.insert(item, at: destIndex)
            }
            
            /// A Little Saftey
            DispatchQueue.main.async {
                swapLock = false
            }
        }
    }
}

struct SortableGridConfig {
    var spacing: CGFloat = 10
    var count: Int = 2
    var previewScale: CGFloat = 1.06
    /// Add More Properties According To Your Needs!
}

fileprivate struct CustomLongPressGesture: UIGestureRecognizerRepresentable {
    var duration: CGFloat = 0.16
    var onChanged: (_ location: CGPoint, _ offset: CGSize) -> ()
    var onEnd: () -> ()
    /// View Properties
    @State private var startLocation: CGPoint?
    func makeUIGestureRecognizer(context: Context) -> UILongPressGestureRecognizer {
        let gesture = UILongPressGestureRecognizer()
        gesture.minimumPressDuration = duration
        gesture.numberOfTapsRequired = 0
        gesture.numberOfTouchesRequired = 1
        return gesture
    }
    
    func updateUIGestureRecognizer(_ recognizer: UILongPressGestureRecognizer, context: Context) {  }
    
    func handleUIGestureRecognizerAction(_ recognizer: UILongPressGestureRecognizer, context: Context) {
        let state = recognizer.state
        let location = recognizer.location(in: recognizer.view)
        /// Converting Location into Translation by storing the first starting location
        /// As this avoids the usage of another gesture (Pan)
        
        switch state {
        case .began, .changed:
            if startLocation == nil { startLocation = location }
            guard let startLocation else { return }
            let translation: CGSize = .init(
                width: location.x - startLocation.x,
                height: location.y - startLocation.y
            )
            
            let localSpaceLocation = context.converter.convert(globalPoint: location, to: .named("SORTABLEGRID"))
            onChanged(localSpaceLocation, translation)
        default:
            startLocation = nil
            onEnd()
        }
    }
}

#Preview {
    ContentView()
}
