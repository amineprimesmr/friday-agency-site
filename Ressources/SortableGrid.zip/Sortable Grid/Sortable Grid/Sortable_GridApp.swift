//
//  Sortable_GridApp.swift
//  Sortable Grid
//
//  Created by Balaji Venkatesh on 28/01/26.
//

import SwiftUI

@main
struct Sortable_GridApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
