//
//  AppleTVCarouselViewApp.swift
//  AppleTVCarouselView
//
//  Created by Balaji Venkatesh on 14/03/26.
//

import SwiftUI

@main
struct AppleTVCarouselViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
