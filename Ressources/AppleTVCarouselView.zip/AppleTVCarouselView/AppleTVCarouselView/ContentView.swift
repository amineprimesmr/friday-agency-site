//
//  ContentView.swift
//  AppleTVCarouselView
//
//  Created by Balaji Venkatesh on 14/03/26.
//

import SwiftUI

/// Dummy Carousel Model & Data
struct TVShow: Identifiable {
    var id: String = UUID().uuidString
    var title: String
    var subtitle: String
    var content: String
    var artwork: String
}

/// Inspired From the Apple TV App Hero Carousel Slider!
let shows: [TVShow] = [
    .init(title: "MONARCH", subtitle: "LEGACY OF MONSTERS", content: "TV Show · Adventure · Sci-Fi", artwork: "Show 1"),
    .init(title: "DARK", subtitle: "MATTER", content: "TV Show · Sci-Fi · Thriller", artwork: "Show 2"),
    .init(title: "FOR ALL", subtitle: "MANKIND", content: "TV Show · Drama · Sci-Fi", artwork: "Show 3"),
    .init(title: "BORN", subtitle: "TO BE WILD", content: "TV Show · Documentary", artwork: "Show 4"),
    .init(title: "TINY", subtitle: "WORLD", content: "TV Show · Documentary", artwork: "Show 5"),
]

struct ContentView: View {
    @State private var activeIndex: Int = 0
    @State private var scrollPhase: ScrollPhase = .idle
    @State private var verticalOffset: CGFloat = 0
    var body: some View {
        ScrollView(.vertical) {
            VStack {
                AppleTVCarousel {
                    ForEach(shows) { show in
                        GeometryReader {
                            let size = $0.size
                            
                            ZStack {
                                Image(show.artwork)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                            }
                            .frame(width: size.width, height: size.height)
                            .overlay(alignment: .bottom) {
                                BottomContent(show)
                            }
                        }
                    }
                } scrollProgress: { progress in
                    activeIndex = min(Int(progress.rounded()), shows.count - 1)
                }
                .onScrollPhaseChange({ oldPhase, newPhase in
                    scrollPhase = newPhase
                })
                .frame(height: 500 + verticalOffset)
                .offset(y: -verticalOffset)
                
                Spacer(minLength: 0)
            }
        }
        .onScrollGeometryChange(for: CGFloat.self, of: {
            $0.contentOffset.y + $0.contentInsets.top
        }, action: { oldValue, newValue in
            verticalOffset = max(-newValue, 0)
        })
        .backgroundExtensionEffect()
    }
    
    /// Bottom Bar Content
    @ViewBuilder
    func BottomContent(_ show: TVShow) -> some View {
        let isActive: Bool = shows[activeIndex].id == show.id
        
        VStack(spacing: 0) {
            Text(show.title)
                .font(.system(size: 50, weight: .black))
            Text(show.subtitle)
                .font(.system(size: 25, weight: .bold))
            
            Text(show.content)
                .font(.callout)
                .fontWeight(.medium)
                .padding(.top, 10)
            
            /// Dummy Buttons
            HStack(spacing: 10) {
                Button {
                    
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "play.fill")
                        Text("Play")
                    }
                    .frame(width: 150, height: 45)
                    .foregroundStyle(.black)
                    .background(.white, in: .capsule)
                }

                Button {
                    
                } label: {
                    Image(systemName: "plus")
                        .font(.title3.bold())
                        .foregroundStyle(.white)
                        .frame(width: 45, height: 45)
                        .background(.white.tertiary, in: .circle)
                }
            }
            .padding(.top, 15)
        }
        .foregroundStyle(.white)
        .compositingGroup()
        .padding(.bottom, 40)
        /// Animating only active card
        .animation(isActive ? .linear(duration: 0.18) : .none) { content in
            content
                .opacity(scrollPhase != .interacting ? 1 : 0)
        }
        .opacity(isActive ? 1 : 0)
    }
}

#Preview {
    ContentView()
}
