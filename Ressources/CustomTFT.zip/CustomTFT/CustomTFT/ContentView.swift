//
//  ContentView.swift
//  CustomTFT
//
//  Created by Balaji Venkatesh on 23/04/26.
//

import SwiftUI

let dummyText: String = """
What is Lorem Ipsum?

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.


"""

struct ContentView: View {
    @State private var text: String = dummyText
    @FocusState private var isKeyboardActive: Bool
    var body: some View {
        NavigationStack {
            TextEditor(text: $text)
                .focused($isKeyboardActive)
                .scrollContentBackground(.hidden)
                .lineSpacing(6)
                .padding(15)
                .navigationTitle("Notes")
                .background {
                    Rectangle()
                        .fill(.fill.opacity(0.3))
                        .ignoresSafeArea()
                }
                .toolbarTitleDisplayMode(.inlineLarge)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Share", systemImage: "square.and.arrow.up") {
                            
                        }
                    }
                    
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Options", systemImage: "ellipsis") {
                            
                        }
                    }
                    
                    ToolbarSpacer(.fixed, placement: .topBarTrailing)
                    
                    ToolbarItem(placement: .topBarTrailing) {
                        if isKeyboardActive {
                            Button("Done", systemImage: "checkmark") {
                                isKeyboardActive = false
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.yellow)
                        }
                    }
                }
                .animation(.easeInOut(duration: 0.25), value: isKeyboardActive)
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    ZStack(alignment: .trailing) {
                        /// Custom Expandable Glass Menu View From My Previous Video
                        /// Link in the description!
                        GeometryReader {
                            let size = $0.size
                            let progress: CGFloat = isKeyboardActive ? 1 : 0
                            let labelSize: CGSize = .init(width: 220, height: size.height)
                            
                            ExpandableGlassMenu(alignment: .center, progress: progress, labelSize: labelSize, cornerRadius: 22.5) {
                                ScrollView(.horizontal) {
                                    HStack(spacing: 30) {
                                        EditorActions()
                                    }
                                    .font(.title3)
                                    .foregroundStyle(Color.primary)
                                    .padding(.horizontal, 25)
                                    .contentShape(.rect)
                                    .scrollTargetLayout()
                                }
                                .scrollTargetBehavior(.viewAligned)
                                .scrollIndicators(.hidden)
                                .frame(width: size.width, height: size.height)
                            } label: {
                                HStack(spacing: 20) {
                                    BaseActions()
                                }
                                .font(.title3)
                                .foregroundStyle(Color.primary)
                            }
                        }
                        .frame(height: 45)
                        .zIndex(1)
                        
                        Button {
                            
                        } label: {
                            Image(systemName: "square.and.pencil")
                                .font(.title3)
                                .frame(width: 25, height: 35)
                        }
                        .buttonStyle(.glass)
                        .buttonBorderShape(.circle)
                        .opacity(isKeyboardActive ? 0 : 1)
                        .blur(radius: isKeyboardActive ? 5 : 0)
                        .scaleEffect(isKeyboardActive ? 0.5 : 1)
                    }
                    .padding(.horizontal, 15)
                    .padding(.bottom, isKeyboardActive ? 10 : 0)
                    /// YOUR DESIRED ANIMATION!
                    .animation(.interactiveSpring(response: 0.5, dampingFraction: 0.65), value: isKeyboardActive)
                }
        }
    }
    
    /// Base Actions
    @ViewBuilder
    func BaseActions() -> some View {
        Group {
            Button("", systemImage: "checklist") {

            }
            
            Button("", systemImage: "paperclip") {
                
            }
            
            Button("", systemImage: "pencil.tip.crop.circle") {
                
            }
            
            Button("", systemImage: "apple.intelligence") {
                
            }
        }
    }
    
    /// Text Editor Actions
    @ViewBuilder
    func EditorActions() -> some View {
        Group {
            Button("", systemImage: "textformat.size") {
                
            }
            
            Button("", systemImage: "checklist") {
                
            }
            
            Button("", systemImage: "tablecells") {
                
            }
            
            Button("", systemImage: "paperclip") {
                
            }
            
            Button("", systemImage: "pencil.tip.crop.circle") {
                
            }
            
            Button("", systemImage: "apple.intelligence") {
                
            }
            
            Button("", systemImage: "bold") {
                
            }
            
            Button("", systemImage: "italic") {
                
            }
            
            Button("", systemImage: "underline") {
                
            }
            
            Button("", systemImage: "strikethrough") {
                
            }
            
            Button("", systemImage: "pencil.line") {
                
            }
            
            Button("", systemImage: "link") {
                
            }
            
            Button("", systemImage: "increase.indent") {
                
            }
            
            Button("", systemImage: "decrease.indent") {
                
            }
            
            Button("", systemImage: "arrow.up.to.line") {
                
            }
            
            Button("", systemImage: "arrow.down.to.line") {
                
            }
        }
    }
}

struct ExpandableGlassMenu<Content: View, Label: View>: View, Animatable {
    var alignment: Alignment
    var progress: CGFloat
    var labelSize: CGSize = .init(width: 55, height: 55)
    var cornerRadius: CGFloat = 30
    @ViewBuilder var content: Content
    @ViewBuilder var label: Label
    /// View Properties
    @State private var contentSize: CGSize = .zero
    
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    
    var body: some View {
        GlassEffectContainer {
            let widthDiff = contentSize.width - labelSize.width
            let heightDiff = contentSize.height - labelSize.height
            
            let rWidth = widthDiff * contentOpacity
            let rHeight = heightDiff * contentOpacity
            
            ZStack(alignment: alignment) {
                content
                    .compositingGroup()
                    .scaleEffect(contentScale)
                    .blur(radius: 14 * blurProgress)
                    .opacity(contentOpacity)
                    .onGeometryChange(for: CGSize.self) {
                        $0.size
                    } action: { newValue in
                        contentSize = newValue
                    }
                    .fixedSize()
                    .frame(
                        width: labelSize.width + rWidth,
                        height: labelSize.height + rHeight
                    )
                
                label
                    .compositingGroup()
                    .blur(radius: 14 * blurProgress)
                    .opacity(1 - labelOpacity)
                    .frame(width: labelSize.width, height: labelSize.height)
            }
            .compositingGroup()
            .clipShape(.rect(cornerRadius: cornerRadius))
            /// OPTIONAL: You can add property to make it clear glass effect!
            .glassEffect(.regular.interactive(), in: .rect(cornerRadius: cornerRadius))
        }
        /// Updating some properties according to this specific type of animation!
        .scaleEffect(
            x: 1 - (blurProgress * 0.25),
            y: 1 + (blurProgress * 0.25),
            anchor: scaleAnchor
        )
        .offset(y: offset * blurProgress)
    }
    
    var labelOpacity: CGFloat {
        min(progress / 0.35, 1)
    }
    
    var contentOpacity: CGFloat {
        max(progress - 0.35, 0) / 0.65
    }
    
    var contentScale: CGFloat {
        let minAspectScale = min(labelSize.width / contentSize.width, labelSize.height / contentSize.height)
        
        return minAspectScale + (1 - minAspectScale) * progress
    }
    
    var blurProgress: CGFloat {
        /// 0 -> 0.5 -> 0
        return progress > 0.5 ? (1 - progress) / 0.5 : progress / 0.5
    }
    
    var offset: CGFloat {
        switch alignment {
        case .bottom, .bottomLeading, .bottomTrailing: return -40
        case .top, .topLeading, .topTrailing: return 40
        /// Center!
        default: return 0
        }
    }
    
    /// Converting Alignment into UnitPoint for ScaleEffect
    var scaleAnchor: UnitPoint {
        switch alignment {
        case .bottomLeading: .bottomLeading
        case .bottom: .bottom
        case .bottomTrailing: .bottomTrailing
        case .topLeading: .topLeading
        case .top: .top
        case .topTrailing: .topTrailing
        case .leading: .leading
        case .trailing: .trailing
        default: .center
        }
    }
}

#Preview {
    ContentView()
}
