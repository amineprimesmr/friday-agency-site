//
//  CustomTFTApp.swift
//  CustomTFT
//
//  Created by Balaji Venkatesh on 23/04/26.
//

import SwiftUI

@main
struct CustomTFTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
