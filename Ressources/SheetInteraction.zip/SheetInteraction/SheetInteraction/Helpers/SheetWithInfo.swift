//
//  SheetWithInfo.swift
//  SheetInteraction
//
//  Created by Balaji Venkatesh on 09/03/26.
//

import SwiftUI

struct SheetInfo {
    var originY: CGFloat?
    var baseViewSize: CGSize = .zero
    var windowSize: CGSize = .zero
    var safeArea: UIEdgeInsets = .init()
}

struct SheetWithInfo<Content: View, Sheet: View>: View {
    @Binding var isPresented: Bool
    @ViewBuilder var content: (SheetInfo) -> Content
    @ViewBuilder var sheet: (SheetInfo) -> Sheet
    /// View Properties
    @State private var info: SheetInfo = .init()
    var body: some View {
        Rectangle()
            .foregroundStyle(.clear)
            .overlay {
                content(info)
            }
            .ignoresSafeArea(.keyboard, edges: .all)
            /// Retreiving Current View Size
            .onGeometryChange(for: CGSize.self, of: {
                $0.size
            }, action: { newValue in
                info.baseViewSize = newValue
            })
            .sheet(isPresented: $isPresented) {
                info.originY = nil
            } content: {
                sheet(info)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(SheetObserver { offset in
                        info.originY = offset
                    })
            }
            .onAppear {
                /// Retreiving Window Size & SafeArea Values
                if let appWindow = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.keyWindow {
                    info.windowSize = appWindow.frame.size
                    info.safeArea = appWindow.safeAreaInsets
                }
            }
    }
}

fileprivate struct SheetObserver: UIViewRepresentable {
    var minY: (CGFloat) -> ()
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        DispatchQueue.main.async {
            context.coordinator.startObserving(view.superview?.superview ?? view)
        }
        
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    class Coordinator {
        var parent: SheetObserver
        init(parent: SheetObserver) {
            self.parent = parent
        }
        
        deinit {
            //print("Stopped")
            displayLink?.invalidate()
        }
        
        weak var observingView: UIView?
        var displayLink: CADisplayLink?
        
        func startObserving(_ view: UIView) {
            observingView = view
            displayLink = CADisplayLink(target: WeakObserver(target: self), selector: #selector(WeakObserver.onChange))
            displayLink?.add(to: .current, forMode: .common)
        }
        
        @objc
        func onChange() {
            guard let view = observingView,
                  let presentation = view.layer.presentation() else {
                return
            }
            
            let globalMinY = presentation.convert(presentation.frame, to: nil).origin.y
            parent.minY(globalMinY)
        }
    }
    
    /// Creating Weak Observer class for the display link as when the Coordinator class is deallocated the display link will also deallocated!
    class WeakObserver {
        weak var target: Coordinator?
        init(target: Coordinator? = nil) {
            self.target = target
        }
        
        @objc
        func onChange() {
            target?.onChange()
        }
    }
}

#Preview {
    ContentView()
}
