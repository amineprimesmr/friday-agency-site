//
//  SheetInteractionApp.swift
//  SheetInteraction
//
//  Created by Balaji Venkatesh on 09/03/26.
//

import SwiftUI

@main
struct SheetInteractionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
