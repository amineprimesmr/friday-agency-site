//
//  ContentView.swift
//  SheetInteraction
//
//  Created by Balaji Venkatesh on 09/03/26.
//

import SwiftUI

struct ContentView: View {
    @State private var showSheet: Bool = false
    var body: some View {
        SheetWithInfo(isPresented: $showSheet) { info in
            ShortsLayout(info: info)
        } sheet: { info in
            CommentsView()
        }
        .background(.black)
        .ignoresSafeArea()
        .overlay(alignment: .bottom) {
            ShortsActions()
                .opacity(showSheet ? 0 : 1)
                .animation(.easeInOut(duration: 0.2), value: showSheet)
        }
    }
    
    /// Dummy Shorts Layout
    @ViewBuilder
    func ShortsLayout(info: SheetInfo) -> some View {
        let safeArea = info.safeArea
        let offset = info.originY ?? 0
        let isVisible = info.originY != nil
        let bottomPadding = max(info.windowSize.height - offset, 0)
        
        let firstDetentHeight = info.windowSize.height * 0.5
        let topSafeAreaValue = safeArea.top + (safeArea.bottom == 0 ? 10 : 0)
        let topOffset = min(bottomPadding / firstDetentHeight, 1) * topSafeAreaValue
        
        Rectangle()
            .fill(.clear)
            .overlay {
                /// YOUR VIDEO PLAYER OR SOME OTHER CONTENT HERE
                AsyncImage(url: URL(string: "https://i.ytimg.com/vi/-YhN9WmYgik/oardefault.jpg")) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                } placeholder: {
                    
                }
            }
            /// Screen based aspect ratio for shorts format!
            .aspectRatio(info.windowSize.width / info.windowSize.height, contentMode: .fit)
            .clipped()
            .padding(.bottom, isVisible ? (bottomPadding + topOffset) : 0)
            .offset(y: isVisible ? topOffset : 0)
    }
    
    @ViewBuilder
    func ShortsActions() -> some View {
        HStack(alignment: .bottom, spacing: 20) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 12) {
                    Text("@iJustine")
                        .foregroundStyle(.white)
                    
                    Button("Subscribe") {
                        
                    }
                    .font(.caption)
                    .foregroundStyle(.black)
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.capsule)
                    .tint(.white)
                }
                
                Text("Exicted about All New Apple Products!")
                    .font(.callout)
                    .foregroundStyle(.white)
            }
            
            Spacer(minLength: 0)
            
            VStack(spacing: 30) {
                Button {
                    
                } label: {
                    Image(systemName: "hand.thumbsup.fill")
                }
                
                Button {
                    
                } label: {
                    Image(systemName: "hand.thumbsdown.fill")
                }
                
                Button {
                    showSheet = true
                } label: {
                    Image(systemName: "text.bubble.fill")
                }
                
                Button {
                    
                } label: {
                    Image(systemName: "arrow.turn.up.right")
                }
                
                Button {
                    
                } label: {
                    Image(systemName: "arrow.trianglehead.2.clockwise")
                }
                
                Button {
                    
                } label: {
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 35, height: 35)
                }
            }
            .font(.title2)
            .foregroundStyle(.white)
        }
        .padding(15)
    }
}

/// Dummy Comments View
struct CommentsView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ScrollView(.vertical) {
            LazyVStack(spacing: 15) {
                ForEach(1...50, id: \.self) { index in
                    HStack(alignment: .top, spacing: 12) {
                        Circle()
                            .frame(width: 25, height: 25)
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Rectangle()
                                .frame(width: 120, height: 10)
                            Rectangle()
                                .frame(width: 250, height: 10)
                            Rectangle()
                                .frame(width: 150, height: 10)
                            if index % 2 == 0 {
                                Rectangle()
                                    .frame(width: 50, height: 10)
                            }
                        }
                    }
                    .foregroundStyle(.fill)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.bottom, 20)
                }
            }
            .padding(15)
        }
        .safeAreaInset(edge: .top, spacing: 0) {
            HStack(spacing: 20) {
                Text("Comments")
                    .font(.title3)
                    .fontWeight(.bold)
                
                Spacer(minLength: 0)
                
                Button {
                    
                } label: {
                    Image(systemName: "slider.horizontal.3")
                }
                
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                }
            }
            .font(.title2)
            .foregroundStyle(.white)
            .padding(15)
            .padding(.top, 5)
            .background(.black)
            .overlay(alignment: .bottom) {
                Rectangle()
                    .frame(height: 0.5)
                    .foregroundStyle(.white.tertiary)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            /// Dummy Comment Bar
            HStack(spacing: 10) {
                TextField("Comment", text: .constant(""))
                    .padding(.vertical, 10)
                    .padding(.horizontal, 15)
                    .background(.fill, in: .capsule)
            }
            .padding(.horizontal, 15)
            .padding(.top, 10)
            .padding(.bottom, 5)
            .background(.black)
            .overlay(alignment: .top) {
                Rectangle()
                    .frame(height: 0.5)
                    .foregroundStyle(.white.tertiary)
            }
        }
        .presentationDetents([.medium, .large])
        .preferredColorScheme(.dark)
        .presentationBackground(.black)
    }
}

#Preview {
    ContentView()
}
