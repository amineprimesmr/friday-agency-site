//
//  MacToasts.swift
//  MToasts
//
//  Created by Balaji Venkatesh on 26/04/26.
//

import SwiftUI

struct MacToast: Codable, Hashable, Identifiable {
    var id: String
    /// Toast Properties
    var toastStyle: ToastStyle
    var symbol: String?
    var title: String
    var subtitle: String?
    var anchor: CGPoint = .init(x: 0.5, y: 0.99)
    var dismissDuration: CGFloat = 2
    /// Add more properties according to your own needs!
    
    enum ToastStyle: String, Codable, CaseIterable {
        case vertical = "Vertical"
        case horizontal = "Horizontal"
    }
}

struct ToastWindow: Scene {
    var body: some Scene {
        WindowGroup(id: "Mac-Toast", for: MacToast.self) { toast in
            if let toast = toast.wrappedValue {
                MacToastView(toast: toast)
            }
        }
        /// Window Customizations
        .windowLevel(.floating)
        .windowStyle(.plain)
        .restorationBehavior(.disabled)
        .windowBackgroundDragBehavior(.disabled)
    }
}

private struct MacToastView: View {
    var toast: MacToast
    /// View Properties
    @State private var isVisible: Bool = false
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        /// Since this supports macOS 15+
        let cornerRadius: CGFloat = 20
        ZStack {
            if #available(macOS 26, *) {
                ToastView()
                    .glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
            } else {
                ToastView()
                    .background(.ultraThinMaterial, in: .rect(cornerRadius: cornerRadius))
            }
        }
        .background(WindowAnchorAdjust(anchor: toast.anchor))
        .opacity(isVisible ? 1 : 0)
        /// Automatic Dismiss after toast duration
        .onAppear {
            let animation = Animation.easeInOut(duration: 0.25)
            withAnimation(animation) {
                isVisible = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + toast.dismissDuration) {
                withAnimation(animation, completionCriteria: .logicallyComplete) {
                    isVisible = false
                } completion: {
                    dismiss()
                }
            }
        }
        /// Disabling Interaction
        .allowsHitTesting(false)
    }
    
    @ViewBuilder
    private func ToastView() -> some View {
        let style = toast.toastStyle
        let isHorizontal = style == .horizontal
        
        let layout = isHorizontal ? AnyLayout(HStackLayout(spacing: 8)) : AnyLayout(VStackLayout(spacing: 15))
        
        layout {
            if let symbol = toast.symbol {
                Image(systemName: symbol)
                    .font(.system(size: isHorizontal ? 15 : 50))
                    .foregroundStyle(Color.primary)
            }
            
            VStack(alignment: .center, spacing: 4) {
                Text(toast.title)
                    .font(.system(size: isHorizontal ? 12 : 16))
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                    .fixedSize()
                
                if let subtitle = toast.subtitle, !isHorizontal {
                    Text(subtitle)
                        .font(.system(size: 10))
                        .foregroundStyle(Color.gray)
                        .lineLimit(2)
                        .multilineTextAlignment(.center)
                        .fixedSize()
                }
            }
        }
        .padding(.horizontal, isHorizontal ? 15 : 20)
        .padding(.vertical, isHorizontal ? 0 : 20)
        .frame(height: isHorizontal ? 40 : nil)
    }
}

private struct WindowAnchorAdjust: NSViewRepresentable {
    var anchor: CGPoint
    func makeNSView(context: Context) -> NSView {
        let view = NSView()
        view.layer?.backgroundColor = .clear
        DispatchQueue.main.async {
            if let window = view.window {
                setWindowAnchor(window)
            }
        }
        
        return view
    }
    
    func updateNSView(_ nsView: NSView, context: Context) {  }
    
    private func setWindowAnchor(_ window: NSWindow) {
        guard let screen = NSScreen.main else { return }
        let windowFrame = window.frame
        let screenFrame = screen.visibleFrame
        
        let valueX = screenFrame.minX + screenFrame.width * anchor.x
        /// Since macOS coordinate system starts from bottom-left
        let valueY = screenFrame.minY + screenFrame.height * (1 - anchor.y)
        
        let anchorX = windowFrame.width * anchor.x
        let anchorY = windowFrame.height * (1 - anchor.y)
        
        window.setFrameOrigin(.init(
            x: valueX - anchorX,
            y: valueY - anchorY
        ))
    }
}
