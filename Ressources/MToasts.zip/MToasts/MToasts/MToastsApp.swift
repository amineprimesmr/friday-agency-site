//
//  MToastsApp.swift
//  MToasts
//
//  Created by Balaji Venkatesh on 26/04/26.
//

import SwiftUI

@main
struct MToastsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowResizability(.contentSize)
        
        /// Add this to your Main App!
        ToastWindow()
    }
}
