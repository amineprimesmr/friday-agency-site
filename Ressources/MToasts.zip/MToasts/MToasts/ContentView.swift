//
//  ContentView.swift
//  MToasts
//
//  Created by Balaji Venkatesh on 26/04/26.
//

import SwiftUI

struct ContentView: View {
    @State private var position: Position = .top
    @State private var style: MacToast.ToastStyle = .horizontal
    @Environment(\.openWindow) private var openWindow
    var body: some View {
        VStack {
            Picker("Toast Style", selection: $style) {
                ForEach(MacToast.ToastStyle.allCases, id: \.rawValue) { style in
                    Text(style.rawValue)
                        .tag(style)
                }
            }
            .pickerStyle(.segmented)
            
            Picker("Toast Position", selection: $position) {
                ForEach(Position.allCases, id: \.rawValue) { position in
                    Text(position.rawValue)
                        .tag(position)
                }
            }
            .pickerStyle(.segmented)
            
            Button("Show Toast") {
                let toast = MacToast(
                    id: UUID().uuidString,
                    toastStyle: style,
                    symbol: "checkmark.seal.fill",
                    title: "Uploaded Sucessfully!",
                    subtitle: "Binary Uploaded to App Store Connect.",
                    anchor: position.anchor,
                    dismissDuration: 2
                )
                
                /// Simply Use Open window environment to present toast!
                openWindow(value: toast)
            }
        }
        .padding()
        .frame(width: 350, height: 350)
    }
    
    enum Position: String, CaseIterable {
        case top = "Top"
        case bottom = "Bottom"
        case center = "Center"
        
        var anchor: CGPoint {
            switch self {
            case .top: return .init(x: 0.5, y: 0.02)
            case .bottom: return .init(x: 0.5, y: 0.98)
            case .center: return .init(x: 0.5, y: 0.5)
            }
        }
    }
}

#Preview {
    ContentView()
}
