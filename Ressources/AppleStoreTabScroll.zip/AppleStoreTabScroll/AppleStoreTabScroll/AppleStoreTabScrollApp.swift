//
//  AppleStoreTabScrollApp.swift
//  AppleStoreTabScroll
//
//  Created by Balaji Venkatesh on 28/02/26.
//

import SwiftUI

@main
struct AppleStoreTabScrollApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
