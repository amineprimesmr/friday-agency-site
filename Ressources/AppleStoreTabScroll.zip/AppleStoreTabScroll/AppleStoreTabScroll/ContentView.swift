//
//  ContentView.swift
//  AppleStoreTabScroll
//
//  Created by Balaji Venkatesh on 28/02/26.
//

import SwiftUI

struct ContentView: View {
    @State private var isScrolledUp: Bool = false
    @State private var storedOffset: CGFloat = 0
    @State private var scrollPhase: ScrollPhase = .idle
    @State private var tabBarVisibility: Visibility = .visible
    var body: some View {
        TabView {
            Tab.init("For You", systemImage: "heart.text.square.fill") {
                ScrollView(.vertical) {
                    VStack(spacing: 12) {
                        ForEach(1...50, id: \.self) { index in
                            Rectangle()
                                .fill(.fill.tertiary)
                                .frame(height: 50)
                                .overlay {
                                    Text("\(index)")
                                }
                        }
                    }
                    .padding(15)
                }
                .scrollIndicators(.hidden)
                .onScrollGeometryChange(for: CGFloat.self) {
                    $0.contentOffset.y + $0.contentInsets.top
                } action: { oldValue, newValue in
                    let threshold: CGFloat = 50
                    let isScrolledUp = oldValue < newValue
                    if self.isScrolledUp != isScrolledUp {
                        let optionalDownThreshold: CGFloat = 10
                        /// Storing current offset
                        storedOffset = newValue - (tabBarVisibility == .hidden ? (threshold + optionalDownThreshold) : 0)
                        self.isScrolledUp = isScrolledUp
                    }
                    
                    let diff = newValue - storedOffset
                    if scrollPhase == .interacting {
                        tabBarVisibility = diff > threshold ? .hidden : .visible
                    }
                }
                .onScrollPhaseChange { oldPhase, newPhase in
                    scrollPhase = newPhase
                }
                .toolbarVisibility(tabBarVisibility, for: .tabBar)
                .animation(.smooth(duration: 0.3, extraBounce: 0), value: tabBarVisibility)
            }
            
            Tab.init("Products", systemImage: "macbook.and.iphone") {
                
            }
            
            Tab.init("More", systemImage: "safari") {
                
            }
            
            Tab.init("Bag", systemImage: "bag") {
                
            }
            
            Tab.init(role: .search) {
                
            }
        }
        .tabViewBottomAccessory {
            Text("From $899, get 10% off on your first purchase!\nUse code: WELCOME10")
                .font(.caption)
                .multilineTextAlignment(.center)
        }
    }
}

#Preview {
    ContentView()
}
