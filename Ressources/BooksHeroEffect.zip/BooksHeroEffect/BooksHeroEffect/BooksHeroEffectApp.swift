//
//  BooksHeroEffectApp.swift
//  BooksHeroEffect
//
//  Created by Balaji Venkatesh on 19/01/26.
//

import SwiftUI

@main
struct BooksHeroEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
