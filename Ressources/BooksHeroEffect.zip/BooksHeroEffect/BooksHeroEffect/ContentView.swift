//
//  ContentView.swift
//  BooksHeroEffect
//
//  Created by Balaji Venkatesh on 19/01/26.
//

import SwiftUI

/// NOTES:
/// 1. Expanding Effect Definitely Requires the sourceIndex property of the config
/// 2. While dismissing only set "expandDetailView" to false is enough

struct ContentView: View {
    @State private var config: ScrollHeroEffectConfig = .init()
    @State private var config1: ScrollHeroEffectConfig = .init()
    @Namespace private var namespace
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 20) {
                    ScenericScrollView()
                    
                    IllustrationsScrollView()
                }
            }
            .safeAreaPadding(.horizontal, 15)
            .navigationTitle("Photos")
            .toolbarTitleDisplayMode(.inlineLarge)
        }
        .overlay {
            /// Place your Detail view at the highest possible order!
            ZStack {
                DetailHeroeEffectScrollView(config: $config, namespace: namespace, data: sceneric, id: \.id) { item, progress in
                    DetailItemView(
                        config: $config,
                        photo: item,
                        progress: progress,
                        namespace: namespace
                    )
                }
                
                DetailHeroeEffectScrollView(config: $config1, namespace: namespace, data: illustrations, id: \.id) { item, progress in
                    DetailItemView(
                        config: $config1,
                        photo: item,
                        progress: progress,
                        namespace: namespace
                    )
                }
            }
            .safeAreaPadding(.horizontal, 20)
        }
    }
    
    /// Sceneric Scroll View
    @ViewBuilder
    func ScenericScrollView() -> some View {
        Section("Sceneric") {
            SourceHeroeEffectScrollView(config: $config, namespace: namespace, data: sceneric, id: \.id) { item in
                ImageView(item)
                    .onTapGesture {
                        if let index = sceneric.firstIndex(where: { $0.id == item.id }) {
                            withAnimation(.interpolatingSpring(duration: 0.3)) {
                                config.sourceIndex = index
                                config.expandDetailView = true
                            }
                        }
                    }
                    .transition(.offset(x: 1))
            }
            .frame(height: 220)
            .scrollIndicators(.hidden)
        }
        .font(.title2.bold())
    }
    
    /// Illustrations Scroll View
    @ViewBuilder
    func IllustrationsScrollView() -> some View {
        Section("Illustartions") {
            SourceHeroeEffectScrollView(config: $config1, namespace: namespace, data: illustrations, id: \.id) { item in
                ImageView(item)
                    .onTapGesture {
                        if let index = illustrations.firstIndex(where: { $0.id == item.id }) {
                            withAnimation(.interpolatingSpring(duration: 0.3)) {
                                config1.sourceIndex = index
                                config1.expandDetailView = true
                            }
                        }
                    }
                    .transition(.offset(x: 1))
            }
            .frame(height: 220)
            .scrollIndicators(.hidden)
        }
        .font(.title2.bold())
    }
    
    /// Image View
    @ViewBuilder
    func ImageView(_ item: Photo) -> some View {
        Rectangle()
            .foregroundStyle(.clear)
            .overlay {
                Image(item.assetName)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            }
            .clipShape(.rect(cornerRadius: 10))
            .matchedGeometryEffect(id: item.imageID, in: namespace)
    }
}

struct DetailItemView: View {
    @Binding var config: ScrollHeroEffectConfig
    var photo: Photo
    var progress: CGFloat
    var namespace: Namespace.ID
    var body: some View {
        ScrollView(.vertical) {
            VStack(spacing: 15) {
                Image(photo.assetName)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 160, height: 220)
                    .clipShape(.rect(cornerRadius: 20))
                    .matchedGeometryEffect(id: photo.imageID, in: namespace)
                
                VStack(spacing: 12) {
                    Text(photo.author)
                        .font(.title3.bold())
                    
                    Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\n\nIt has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum")
                        .font(.system(size: 14))
                        .foregroundStyle(.secondary)
                        .kerning(0.5)
                }
                .compositingGroup()
                .blur(radius: blur)
                .opacity(opacity)
                .padding(.top, 10)
            }
            .padding(15)
        }
        .safeAreaInset(edge: .bottom) {
            BottomBar()
                .compositingGroup()
                .blur(radius: blur)
                .opacity(opacity)
        }
        .overlay(alignment: .topTrailing) {
            /// Close Button
            Button {
                withAnimation(.interpolatingSpring(duration: 0.3)) {
                    config.expandDetailView = false
                }
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 24))
                    .foregroundStyle(Color.primary.secondary)
                    .padding(15)
                    .contentShape(.rect)
            }
            .opacity(opacity)
        }
    }
    
    /// Custom Bottom Bar
    @ViewBuilder
    func BottomBar() -> some View {
        HStack(spacing: 10) {
            Button {
                
            } label: {
                Text("+Favourites")
                    .padding(.vertical, 5)
                    .frame(maxWidth: .infinity)
            }
            .tint(.red)
            
            Button {
                
            } label: {
                Text("Download")
                    .padding(.vertical, 5)
                    .frame(maxWidth: .infinity)
            }
            .tint(.blue)
        }
        .font(.callout)
        .fontWeight(.semibold)
        .buttonStyle(.borderedProminent)
        .buttonBorderShape(.capsule)
        .padding(.horizontal, 15)
        .padding(.vertical, 10)
        .overlay(alignment: .top) {
            Divider()
        }
    }
    
    /// Let's Convert the progress to opacity to only show after specific limit!
    var opacity: CGFloat {
        return progress > 0.7 ? min((progress - 0.7) * 3.4, 1) : 0
    }
    
    var blur: CGFloat {
        return (1 - progress) * 6
    }
}

#Preview {
    ContentView()
}
