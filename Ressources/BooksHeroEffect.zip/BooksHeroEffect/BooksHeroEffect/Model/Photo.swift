//
//  Photo.swift
//  BooksHeroEffect
//
//  Created by Balaji Venkatesh on 19/01/26.
//

import SwiftUI

struct Photo: Identifiable {
    var id: UUID = .init()
    var assetName: String
    var author: String
    
    var imageID: String {
        "IMG:\(id.uuidString)"
    }
}

let sceneric: [Photo] = [
    // Photo by eberhard grossgasteiger: https://www.pexels.com/photo/person-showing-gray-mountain-534164/
    .init(assetName: "S1", author: "Eberhard Grossgasteiger"),
    // Photo by Symeon Ekizoglou: https://www.pexels.com/photo/islet-2880802/
    .init(assetName: "S2", author: "Symeon Ekizoglou"),
    // Photo by Mikhail Nilov: https://www.pexels.com/photo/aerial-shot-of-body-of-water-8322789/
    .init(assetName: "S3", author: "Mikhail Nilov"),
    // Photo by Dalton Douglas: https://www.pexels.com/photo/wide-road-2386939/
    .init(assetName: "S4", author: "Dalton Douglas")
]

let illustrations: [Photo] = [
    // Photo by Moose Photos: https://www.pexels.com/photo/classic-blue-coupe-die-cast-model-1037995/
    .init(assetName: "I1", author: "Moose Photos"),
    // Photo by Steve Johnson: https://www.pexels.com/photo/shiny-dark-polygons-9977649/
    .init(assetName: "I2", author: "Steve Johnson"),
    // Photo by Johannes Plenio: https://www.pexels.com/photo/gray-and-white-wallpaper-1103970/
    .init(assetName: "I3", author: "Johannes Plenio"),
    // Photo by Steve Johnson: https://www.pexels.com/photo/3d-render-of-an-object-13156182/
    .init(assetName: "I4", author: "Steve Johnson")
]
