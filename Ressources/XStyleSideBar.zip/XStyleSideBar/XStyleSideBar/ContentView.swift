//
//  ContentView.swift
//  XStyleSideBar
//
//  Created by Balaji Venkatesh on 08/05/26.
//

import SwiftUI

struct ContentView: View {
    @State private var activeTab: Int = 0
    @State private var navigationPath: NavigationPath = .init()
    @State private var isExpanded: Bool = false
    var body: some View {
        let isMenuEnabled = navigationPath.isEmpty
        
        CustomSideMenu(isEnabled: isMenuEnabled, isExpanded: $isExpanded) { progress in
            SideBar(
                isExpanded: $isExpanded,
                path: $navigationPath
            )
        } content: { progress in
            NavigationStack(path: $navigationPath) {
                TabView(selection: $activeTab) {
                    Tab.init("Home", systemImage: "house", value: 0) {
                        ScrollView(.vertical) {
                            VStack(spacing: 20) {
                                ForEach(1...15, id: \.self) { index in
                                    DummyCardView()
                                }
                            }
                            .padding(15)
                        }
                    }
                    
                    Tab.init("Search", systemImage: "magnifyingglass", value: 1) {
                        
                    }
                    
                    Tab.init("Notifications", systemImage: "bell", value: 2) {
                        
                    }
                    
                    Tab.init("Profile", systemImage: "person", value: 3) {
                        
                    }
                }
                .toolbarVisibility(.hidden, for: .navigationBar)
                .navigationDestination(for: String.self) { value in
                    Text("Hello World")
                        .navigationTitle(value)
                }
            }
        }
    }
    
    @ViewBuilder
    func DummyCardView() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Circle()
                    .fill(.fill)
                    .frame(width: 40, height: 40)
                
                VStack(alignment: .leading, spacing: 5) {
                    Rectangle()
                        .fill(.fill)
                        .frame(width: 120, height: 15)
                    
                    Rectangle()
                        .fill(.fill)
                        .frame(height: 15)
                }
            }
            
            Rectangle()
                .foregroundStyle(.fill)
                .frame(height: 250)
                .padding(.leading, 50)
            
            HStack(spacing: 0) {
                Group {
                    Image(systemName: "bubble")
                    Image(systemName: "arrow.2.squarepath")
                    Image(systemName: "suit.heart")
                    Image(systemName: "bookmark")
                    Image(systemName: "square.and.arrow.up")
                }
                .foregroundStyle(.fill)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.leading, 50)
        }
    }
}

struct SideBar: View {
    @Binding var isExpanded: Bool
    @Binding var path: NavigationPath
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Circle()
                .fill(.fill)
                .frame(width: 60, height: 60)
                .padding(.bottom, 10)
            
            Text("iJustine")
                .font(.title3)
                .fontWeight(.semibold)
            
            Text("@iJustine")
                .foregroundStyle(.gray)
            
            HStack(spacing: 2) {
                Text("3K")
                    .fontWeight(.bold)
                
                Text("Following")
                    .foregroundStyle(.primary.opacity(0.7))
                
                Text("1.7M")
                    .fontWeight(.bold)
                    .padding(.leading, 10)
                
                Text("Followers")
                    .foregroundStyle(.primary.opacity(0.7))
            }
            .font(.callout)
            .fontWeight(.medium)
            .padding(.top, 5)
            
            ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 30) {
                    CustomLabelButton(icon: "video", title: "Video") {
                        path.append("Video")
                    }
                    
                    CustomLabelButton(icon: "bookmark", title: "Bookmarks") {
                        path.append("Bookmarks")
                    }
                    
                    CustomLabelButton(icon: "person.2", title: "Communities") {
                        path.append("Communities")
                    }
                    
                    CustomLabelButton(icon: "bubble", title: "Messages") {
                        path.append("Messages")
                    }
                    
                    CustomLabelButton(icon: "list.clipboard", title: "Lists") {
                        path.append("Lists")
                    }
                    
                    CustomLabelButton(icon: "mic", title: "Spaces") {
                        path.append("Spaces")
                    }
                    
                    Divider()
                        .background(.white.tertiary)
                    
                    CustomLabelButton(icon: "gearshape", title: "Settings") {
                        path.append("Spaces")
                    }
                    
                    CustomLabelButton(icon: "questionmark.circle", title: "Help Center") {
                        path.append("Spaces")
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 20)
            }
            .mask {
                Rectangle()
                    .ignoresSafeArea()
            }
            .overlay(alignment: .top) {
                Divider()
                    .background(.white.tertiary)
                    .padding(.horizontal, -15)
            }
            .padding(.top, 15)
            .scrollClipDisabled()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding([.horizontal, .top], 15)
    }
    
    @ViewBuilder
    func CustomLabelButton(
        icon: String,
        title: String,
        action: @escaping () -> ()
    ) -> some View {
        Button(action: {
            isExpanded = false
            action()
        }) {
            HStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.title3)
                    .frame(width: 30)
                    .symbolVariant(.fill)
                
                Text(title)
                    .font(.title3)
                    .fontWeight(.bold)
            }
            .foregroundStyle(Color.primary)
        }
    }
}

#Preview {
    ContentView()
}

