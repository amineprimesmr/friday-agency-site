//
//  XStyleSideBarApp.swift
//  XStyleSideBar
//
//  Created by Balaji Venkatesh on 08/05/26.
//

import SwiftUI

@main
struct XStyleSideBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
