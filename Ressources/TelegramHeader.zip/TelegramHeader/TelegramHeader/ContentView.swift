//
//  ContentView.swift
//  TelegramHeader
//
//  Created by Balaji Venkatesh on 22/03/26.
//

import SwiftUI

struct ContentView: View {
    @State private var safeAreaTopValue: CGFloat = 0
    var body: some View {
        NavigationStack {
            List {
                NavigationLink("Header Scroll Effect") {
                    Group {
                        if #available(iOS 26, *) {
                            TelegramHeaderView()
                                .scrollEdgeEffectHidden(true, for: .top)
                        } else {
                            TelegramHeaderView()
                        }
                    }
                    .toolbarBackgroundVisibility(.hidden, for: .navigationBar)
                    .safeAreaPadding(.top, safeAreaTopValue)
                    .ignoresSafeArea(.all, edges: .top)
                }
            }
            .navigationTitle("Telegram")
        }
        .onGeometryChange(for: CGFloat.self) {
            $0.safeAreaInsets.top
        } action: { newValue in
            safeAreaTopValue = newValue
        }
    }
}

#Preview("Regular") {
    TelegramHeaderView()
}

#Preview("NavigationStack") {
    ContentView()
}
