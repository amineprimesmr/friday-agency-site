//
//  TelegramHeaderApp.swift
//  TelegramHeader
//
//  Created by Balaji Venkatesh on 22/03/26.
//

import SwiftUI

@main
struct TelegramHeaderApp: App {
    var body: some Scene {
        WindowGroup {
            TelegramHeaderView()
        }
    }
}
