//
//  TelegramHeaderView.swift
//  TelegramHeader
//
//  Created by Balaji Venkatesh on 22/03/26.
//

import SwiftUI

struct TelegramHeaderView: View {
    @State private var isLargeHeader: Bool = false
    @State private var topInset: CGFloat = 0
    @State private var scrollPhase: ScrollPhase = .idle
    var body: some View {
        ScrollView(.vertical) {
            LazyVStack {
                SomeDummyContent()
            }
            .padding(15)
            .padding(.bottom, 1000)
            .safeAreaInset(edge: .top, spacing: 0) {
                CustomHeader(isLargeHeader: $isLargeHeader, topInset: $topInset)
            }
        }
        .background(.fill.tertiary)
        /// Reading Top Inset Value
        .onScrollGeometryChange(for: CGFloat.self) {
            $0.contentInsets.top
        } action: { oldValue, newValue in
            topInset = newValue
        }
        /// Activating Large Header based on scroll offset and scroll interaction type
        .onScrollGeometryChange(for: CGFloat.self) {
            $0.contentOffset.y + $0.contentInsets.top
        } action: { oldValue, newValue in
            if scrollPhase == .interacting {
                withAnimation(.snappy(duration: 0.2, extraBounce: 0)) {
                    /// For safer side using -10 value instead of 0!
                    isLargeHeader = newValue < -10 || (isLargeHeader && newValue < 0)
                }
            }
        }
        /// Reading Current Scroll Interaction Type
        .onScrollPhaseChange { oldPhase, newPhase in
            scrollPhase = newPhase
        }
    }
    
    @ViewBuilder
    private func SomeDummyContent() -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Share Link")
                .font(.caption)
            
            let link = "https://apple.com"
            Link(link, destination: URL(string: link)!)
            
            Divider()
                .padding(.vertical, 10)
            
            Text("Description")
                .font(.caption)
            
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")
                .lineLimit(1)
        }
        .padding(15)
        .background(.background, in: .rect(cornerRadius: 25))
    }
}

/// Custom Telegram Style Header
struct CustomHeader: View {
    @Binding var isLargeHeader: Bool
    @Binding var topInset: CGFloat
    @Environment(\.colorScheme) private var colorScheme
    var body: some View {
        VStack(spacing: 12) {
            /// PlaceHolder Logo View than the actual Logo View
            Rectangle()
                .foregroundStyle(.clear)
                .frame(width: 100, height: isLargeHeader ? 300 : 100)
                .clipShape(.circle)
            
            VStack(spacing: 20) {
                CustomNavigationBar()
                    .foregroundStyle(isLargeHeader ? .white : .primary)
                
                HeaderActions()
                    .foregroundStyle(isLargeHeader ? .white : .blue)
                    .geometryGroup()
            }
        }
        .padding(.horizontal, 15)
        .padding(.bottom, 15)
        .background(alignment: .top) {
            /// Resizable Logo View
            GeometryReader {
                let size = $0.size
                let minY = $0.frame(in: .global).minY
                let topOffset = isLargeHeader ? minY : 0
                
                LogoView()
                    .frame(
                        width: size.width,
                        height: size.height + topOffset
                    )
                    .clipShape(.rect(cornerRadius: isLargeHeader ? 0 : 50))
                    .offset(y: -topOffset)
            }
            .frame(
                width: isLargeHeader ? nil : 100,
                height: isLargeHeader ? nil : 100,
            )
        }
        .padding(.top, 15)
    }
    
    /// LOGO VIEW
    @ViewBuilder
    private func LogoView() -> some View {
        ZStack {
            Rectangle()
                .fill(.black)

            Image(systemName: "apple.logo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .foregroundStyle(.white)
                .frame(height: isLargeHeader ? 200 : 55)
                .offset(y: isLargeHeader ? -70 : 0)
        }
    }
    
    /// CUSTOM NAVIGATION BAR
    @ViewBuilder
    private func CustomNavigationBar() -> some View {
        VStack(alignment: isLargeHeader ? .leading : .center, spacing: 6) {
            Text("Apple Development")
                .font(.title)
                .fontWeight(.semibold)
            
            Text("133 Members, 13 Online")
                .font(.callout)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: isLargeHeader ? .leading : .center)
        /// Sticky Header
        .visualEffect { content, proxy in
            let minY = proxy.frame(in: .scrollView(axis: .vertical)).minY
            let progress = max(min(minY / 50, 1), 0)
            
            return content
                .scaleEffect(0.7 + (0.3 * progress))
                .offset(y: minY < 0 ? -minY : 0)
        }
        .background(NavigationBarBackground())
        .zIndex(1000)
    }
    
    /// NAVIGATION BAR BACKGROUND
    @ViewBuilder
    func NavigationBarBackground() -> some View {
        GeometryReader {
            let minY = $0.frame(in: .scrollView(axis: .vertical)).minY
            let opacity: CGFloat = 1.0 - max(min(minY / 50, 1), 0)
            let tint: Color = colorScheme == .dark ? Color.black : Color.white
            
            ZStack {
                /// We can mimic a soft blur effect for iOS 26+ devices using clear glass effect!
                if #available(iOS 26, *) {
                    Rectangle()
                        .fill(.clear)
                        .glassEffect(.clear.tint(tint.opacity(0.8)), in: .rect)
                        /// Progressive blur kinda masking
                        .mask {
                            LinearGradient(colors: [
                                .black,
                                .black,
                                .black,
                                .black,
                                .black.opacity(0.5),
                                .clear
                            ], startPoint: .top, endPoint: .bottom)
                        }
                } else {
                    Rectangle()
                        .fill(tint)
                        /// Progressive blur kinda masking
                        .mask {
                            LinearGradient(colors: [
                                .black,
                                .black,
                                .black,
                                .black.opacity(0.9),
                                .black.opacity(0.4),
                                .clear
                            ], startPoint: .top, endPoint: .bottom)
                        }
                }
            }
            .padding(-20)
            .padding(.bottom, -40)
            .padding(.top, -topInset)
            .offset(y: -minY)
            .opacity(opacity)
        }
        .allowsHitTesting(false)
    }
    
    /// CUSTOM ACTIONS
    @ViewBuilder
    private func HeaderActions() -> some View {
        HStack(spacing: 6) {
            CustomActionButton(isLargeHeader: isLargeHeader, icon: "bell.fill", title: "Mute")
            CustomActionButton(isLargeHeader: isLargeHeader, icon: "magnifyingglass", title: "Search")
            CustomActionButton(isLargeHeader: isLargeHeader, icon: "rectangle.portrait.and.arrow.forward", title: "Leave")
            CustomActionButton(isLargeHeader: isLargeHeader, icon: "ellipsis", title: "More")
        }
    }
}

struct CustomActionButton: View {
    var isLargeHeader: Bool
    var icon: String
    var title: String
    var onTap: () -> () = {  }
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 2) {
                Image(systemName: icon)
                    .font(.title3)
                    .frame(height: 30)
                
                Text(title)
                    .font(.caption)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 5)
            .background {
                ZStack {
                    RoundedRectangle(cornerRadius: 15)
                        .fill(.background)
                        .opacity(isLargeHeader ? 0 : 1)
                    
                    RoundedRectangle(cornerRadius: 15)
                        .fill(.ultraThinMaterial)
                        .opacity(isLargeHeader ? 0.8 : 0)
                        .environment(\.colorScheme, .dark)
                }
            }
            .contentShape(.rect)
        }
    }
}

#Preview {
    TelegramHeaderView()
}
