//
//  ContentView.swift
//  Map_Carousel
//
//  Created by Balaji Venkatesh on 28/11/25.
//

import SwiftUI
import MapKit

struct ContentView: View {
    @State private var showView: Bool = false
    var body: some View {
        NavigationStack {
            List {
                Button("Show View") {
                    showView.toggle()
                }
            }
            .navigationTitle("Map Carousel")
        }
        .fullScreenCover(isPresented: $showView) {
            CustomMapView(
                userRegion: .applePark,
                userCoordinates: MKCoordinateRegion.applePark.center,
                lookupText: "Starbucks",
                limit: 5
            )
        }
    }
}

#Preview {
    ContentView()
}
