//
//  Map_CarouselApp.swift
//  Map_Carousel
//
//  Created by Balaji Venkatesh on 28/11/25.
//

import SwiftUI

@main
struct Map_CarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
