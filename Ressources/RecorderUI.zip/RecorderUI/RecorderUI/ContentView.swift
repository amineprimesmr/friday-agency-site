//
//  ContentView.swift
//  RecorderUI
//
//  Created by Balaji Venkatesh on 06/01/26.
//

import SwiftUI

struct ContentView: View {
    @State private var message: String = ""
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Usage:")
                        .font(.caption2)
                        .foregroundStyle(.gray)
                    
                    Text(
                        """
                        **ChatBottomBar(message)** {
                          // Send Message
                        } **onRecordingStart:** {
                            
                        } **onRecordingFinished:** { discarded
                            
                        } **openMenu:** {
                            
                        }
                        """
                    )
                    .font(.callout)
                    .monospaced()
                    .padding(15)
                    .frame(maxWidth: .infinity)
                    .background(.bar, in: .rect(cornerRadius: 10))
                }
                .padding(15)
            }
            .navigationTitle("iJustine")
            .scrollDismissesKeyboard(.interactively)
            .safeAreaInset(edge: .bottom) {
                ChatBottomBar(message: $message) {
                    print("Send Message")
                } onRecordingStart: {
                    print("Start Recording")
                } onRecordingFinished: { discarded in
                    if discarded {
                        print("Discard Recording")
                    } else {
                        print("Send Recording")
                    }
                } addMenu: {
                    print("Open Menu")
                }
                .padding(.horizontal, 15)
                .padding(.bottom, 12)
            }
        }
    }
}

#Preview {
    ContentView()
}
