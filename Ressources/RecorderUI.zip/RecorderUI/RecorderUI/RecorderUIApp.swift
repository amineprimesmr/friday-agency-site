//
//  RecorderUIApp.swift
//  RecorderUI
//
//  Created by Balaji Venkatesh on 06/01/26.
//

import SwiftUI

@main
struct RecorderUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
