//
//  ChatBottomBar.swift
//  RecorderUI
//
//  Created by Balaji Venkatesh on 07/01/26.
//

import SwiftUI

struct ChatBottomBar: View {
    var hint: String = "Type your message..."
    @Binding var message: String
    var sendMessage: () -> ()
    var onRecordingStart: () -> ()
    var onRecordingFinished: (_ discarded: Bool) -> ()
    var addMenu: () -> () = { }
    /// Gesture Properties
    @GestureState private var isHolding: Bool = false
    @GestureState private var isRecording: Bool = false
    @GestureState private var recorderOffset: CGFloat = 0
    /// View Properties
    @State private var lastRecorderOffset: CGFloat = 0
    @State private var recorderStartTimeStamp: Date = .now
    @State private var disableBottomBar: Bool = false
    var body: some View {
        HStack(spacing: 10) {
            HStack(spacing: 6) {
                AnimatedMenuButton(
                    isRecording: isRecording,
                    disableBottomBar: $disableBottomBar,
                    action: addMenu
                )
                
                TextField(hint, text: $message, axis: .vertical)
                    .lineLimit(5)
                    .opacity(isRecording ? 0 : 1)
                    .overlay(alignment: .trailing) {
                        if isRecording {
                            HStack(spacing: 0) {
                                Text(recorderStartTimeStamp, style: .timer)
                                    .font(.callout)
                                    .fontWeight(.medium)
                                    .foregroundStyle(.gray)
                                
                                Spacer(minLength: 0)
                                
                                SlideToCancelText(text: "Slide to cancel")
                            }
                            .padding(.trailing, 10)
                        }
                    }
                    .animation(.interpolatingSpring(duration: 0.3), value: isRecording)
            }
            .padding(.horizontal, 12)
            .frame(height: 48)
            .background(.ultraThinMaterial, in: .capsule)
            .mask {
                Rectangle()
                    /// For any shadows you've applied!
                    .padding(-50)
                    .padding(.trailing, abs(recorderOffset))
            }
            .shadow(radius: 1)
            
            Image(systemName: mainActionSymbol)
                .font(.system(size: 20, weight: .medium))
                .foregroundStyle(.white)
                .contentTransition(.symbolEffect(.replace, options: .default.speed(1.2)))
                .frame(width: 48, height: 48)
                .background(.blue.gradient, in: .circle)
                .scaleEffect(isHolding ? 1.28 : 1)
                .offset(x: recorderOffset)
                .gesture(sendMessageGesture, isEnabled: !message.isEmpty)
                .gesture(
                    LongPressGesture(minimumDuration: 0.3)
                        .sequenced(before: DragGesture(minimumDistance: 10))
                        .updating($isHolding, body: { _, out, _ in
                            out = true
                        }).updating($isRecording, body: { value, out, _ in
                            if case .second(_, _) = value {
                                /// Successfully entered drag gesture after long press
                                out = true
                            }
                        }).updating($recorderOffset, body: { value, out, _ in
                            if case let .second(_, gesture) = value, let gesture {
                                let translation = gesture.translation.width
                                /// Update this according to your own needs!
                                let cappedOffset = max(min(translation, 0), -200)
                                out = cappedOffset
                            }
                        }),
                    isEnabled: message.isEmpty
                )
        }
        .animation(.interpolatingSpring(duration: 0.4), value: isHolding)
        .animation(.interactiveSpring(duration: 0.3), value: recorderOffset == 0)
        .onChange(of: isRecording) { oldValue, newValue in
            if newValue {
                recorderStartTimeStamp = .now
                onRecordingStart()
            } else {
                /// YOUR OWN CONDITION TO DISCARD THE RECORDING
                if -lastRecorderOffset > 50 {
                    disableBottomBar = true
                    onRecordingFinished(true)
                } else {
                    onRecordingFinished(false)
                }
                
                lastRecorderOffset = 0
            }
        }
        .onChange(of: recorderOffset) { oldValue, newValue in
            if isRecording {
                lastRecorderOffset = newValue
            }
        }
        /// Without using disabled or allowHitTesting (Disabling Interaction)
        /// Why? -> When doing so it hides the keyboard and the animation will look janky!
        .overlay {
            if disableBottomBar {
                Rectangle()
                    .foregroundStyle(.clear)
                    .contentShape(.rect)
                    .transition(.identity)
            }
        }
    }
    
    var mainActionSymbol: String {
        let recordingSymbol: String = isRecording ? "waveform" : "mic.fill"
        return message.isEmpty ? recordingSymbol : "paperplane.fill"
    }
    
    /// Send Message Gesture
    var sendMessageGesture: some Gesture {
        TapGesture(count: 1).onEnded { _ in
            sendMessage()
        }
    }
}

struct AnimatedMenuButton: View {
    var isRecording: Bool
    /// Disables bottom bar when animation is active thus avoids any unnecessary interactions!
    @Binding var disableBottomBar: Bool
    var action: () -> ()
    @State private var keyFrameTrigger: Bool = false
    @State private var isTrashOpen: Bool = false
    var body: some View {
        Button(action: action) {
            ZStack {
                if isRecording || disableBottomBar {
                    Image(systemName: "mic")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundStyle(Color.primary)
                        .transition(.scale(scale: 0.5).combined(with: .opacity))
                        .keyframeAnimator(initialValue: KeyFrame(), trigger: keyFrameTrigger) { content, frame in
                            content
                                .scaleEffect(frame.scale, anchor: .bottom)
                                .rotationEffect(.init(degrees: frame.rotation))
                                .offset(y: frame.offset)
                                .opacity(frame.opacity)
                        } keyframes: { _ in
                            /// Total Duration: 0.6s
                            CubicKeyframe(KeyFrame(offset: -50, rotation: 360), duration: 0.25)
                            
                            CubicKeyframe(KeyFrame(scale: 0.5, offset: 0, rotation: 360), duration: 0.25)
                            
                            CubicKeyframe(KeyFrame(opacity: 0, scale: 0.5, offset: 0, rotation: 360), duration: 0.1)
                        }
                } else {
                    Image(systemName: "plus")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundStyle(Color.primary)
                        .transition(.scale(scale: 0.5).combined(with: .opacity))
                }
                
                CustomTrashCanView(isTrashOpen)
                    .keyframeAnimator(initialValue: KeyFrame(opacity: 0, scale: 0.5), trigger: keyFrameTrigger) { content, frame in
                        content
                            .scaleEffect(frame.scale)
                            .opacity(frame.opacity)
                    } keyframes: { _ in
                        /// Total Duration: 0.9s
                        CubicKeyframe(KeyFrame(scale: 1), duration: 0.2)
                        CubicKeyframe(KeyFrame(scale: 1), duration: 0.5)
                        CubicKeyframe(KeyFrame(opacity: 0, scale: 0.5), duration: 0.2)
                    }
            }
            .frame(width: 30)
        }
        .allowsHitTesting(!isRecording)
        .animation(.easeInOut(duration: 0.3), value: isRecording)
        .animation(.easeInOut(duration: 0.3), value: disableBottomBar)
        .onChange(of: disableBottomBar) { oldValue, newValue in
            /// Triggering Keyframe
            if newValue {
                keyFrameTrigger.toggle()
                
                Task { @MainActor in
                    isTrashOpen = true
                    try? await Task.sleep(for: .seconds(0.5))
                    isTrashOpen = false
                    try? await Task.sleep(for: .seconds(0.2))
                    disableBottomBar = false
                }
            }
        }
    }
    
    @ViewBuilder
    func CustomTrashCanView(_ isOpen: Bool) -> some View {
        VStack(spacing: 2) {
            VStack(spacing: 0) {
                UnevenRoundedRectangle(
                    topLeadingRadius: 10,
                    bottomLeadingRadius: 0,
                    bottomTrailingRadius: 0,
                    topTrailingRadius: 10
                )
                .frame(width: 15, height: 6)
                
                Capsule()
                    .frame(height: 4)
            }
            .compositingGroup()
            .rotationEffect(.init(degrees: isOpen ? -90 : 0), anchor: .bottomLeading)
            .offset(y: isOpen ? 10 : 0)
            
            UnevenRoundedRectangle(
                topLeadingRadius: 0,
                bottomLeadingRadius: 5,
                bottomTrailingRadius: 5,
                topTrailingRadius: 0
            )
                .frame(width: 20, height: 20)
        }
        .frame(width: 25)
        .foregroundStyle(.gray)
        .compositingGroup()
        .scaleEffect(0.8)
        .animation(.easeInOut(duration: 0.3), value: isOpen)
    }
    
    @Animatable
    struct KeyFrame {
        var opacity: CGFloat = 1
        var scale: CGFloat = 1
        var offset: CGFloat = 0
        var rotation: CGFloat = 0
    }
}

#Preview {
    ContentView()
}
