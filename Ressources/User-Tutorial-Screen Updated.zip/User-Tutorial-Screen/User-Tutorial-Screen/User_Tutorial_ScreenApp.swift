//
//  User_Tutorial_ScreenApp.swift
//  User-Tutorial-Screen
//
//  Created by Balaji Venkatesh on 10/08/25.
//

import SwiftUI

@main
struct User_Tutorial_ScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
