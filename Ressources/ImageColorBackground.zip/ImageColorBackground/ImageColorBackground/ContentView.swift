//
//  ContentView.swift
//  ImageColorBackground
//
//  Created by Balaji Venkatesh on 04/04/26.
//

import SwiftUI

/// Dummy Model
struct PlayerItem: Identifiable {
    var id: String = UUID().uuidString
    var title: String
    var subtitle: String
    var image: UIImage?
}

/// Dummy Data
let items: [PlayerItem] = [
    .init(title: "iJustine", subtitle: "Person", image: .init(named: "Pic 0")),
    .init(title: "Tahoe", subtitle: "Apple", image: .init(named: "Pic 1")),
    .init(title: "Mac", subtitle: "Apple", image: .init(named: "Pic 3")),
    .init(title: "The Lake", subtitle: "Apple", image: .init(named: "Pic 4")),
    .init(title: "Sonoma", subtitle: "Apple", image: .init(named: "Pic 2")),
    .init(title: "Macbook", subtitle: "Apple", image: .init(named: "Pic 5")),
]

struct ContentView: View {
    @State private var index: Int = 0
    var body: some View {
        ZStack {
            ImageGradient(
                image: items[index].image,
                count: 4,
                animation: .smooth
            )
            .ignoresSafeArea()
            
            DummyPlayerView(item: items[index])
        }
        .contentShape(.rect)
    }
    
    /// Dummy View
    @ViewBuilder
    private func DummyPlayerView(item: PlayerItem) -> some View {
        VStack(spacing: 12) {
            ZStack {
                if let image = items[index].image {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 280, height: 280)
                        .clipShape(.rect(cornerRadius: 15))
                }
            }
            .frame(maxHeight: .infinity)
            .animation(.smooth, value: index)
            
            HStack(spacing: 15) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title)
                        .font(.title.bold())
                        .foregroundStyle(.white)
                    
                    Text(item.subtitle)
                        .fontWeight(.medium)
                        .foregroundStyle(.white.secondary)
                }
                .contentTransition(.numericText())
                
                Spacer(minLength: 0)
                
                Button {
                    
                } label: {
                    Image(systemName: "star.circle.fill")
                        .font(.title)
                }
                .foregroundStyle(.white, .white.tertiary)

                Button {
                    
                } label: {
                    Image(systemName: "ellipsis.circle.fill")
                        .font(.title)
                }
                .foregroundStyle(.white, .white.tertiary)
            }
            .animation(.smooth, value: index)
            
            VStack(spacing: 2) {
                if #available(iOS 26, *) {
                    Slider(value: .constant(0.5))
                        .sliderThumbVisibility(.hidden)
                        .tint(.white)
                } else {
                    Slider(value: .constant(0.5))
                }
                
                HStack {
                    Text("0:00")
                    Spacer(minLength: 0)
                    Text("4:31")
                }
                .foregroundStyle(.white)
                .font(.caption)
            }
            .padding(.top, 10)
            
            HStack {
                Button {
                    index = max(index - 1, 0)
                } label: {
                    Image(systemName: "backward.fill")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .contentShape(.rect)
                }
                
                Button {
                    
                } label: {
                    Image(systemName: "play.fill")
                        .font(.system(size: 50))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .contentShape(.rect)
                }
                
                Button {
                    index = min(index + 1, 5)
                } label: {
                    Image(systemName: "forward.fill")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .contentShape(.rect)
                }
            }
            .foregroundStyle(.white)
            .font(.largeTitle)
            .frame(height: 150)
            
            VStack(spacing: 2) {
                HStack(spacing: 10) {
                    Image(systemName: "speaker.fill")
                        .foregroundStyle(.white.secondary)
                    
                    if #available(iOS 26, *) {
                        Slider(value: .constant(1))
                            .sliderThumbVisibility(.hidden)
                            .tint(.white)
                    } else {
                        Slider(value: .constant(1))
                    }
                    
                    Image(systemName: "speaker.wave.3.fill")
                        .foregroundStyle(.white.secondary)
                }
                
                HStack {
                    Image(systemName: "quote.bubble")
                        .frame(maxWidth: .infinity)
                    
                    Image(systemName: "airpods.gen4")
                        .frame(maxWidth: .infinity)
                    
                    Image(systemName: "list.dash")
                        .frame(maxWidth: .infinity)
                }
                .font(.title3)
                .foregroundStyle(.white)
                .padding(.top, 10)
            }
            .padding(.vertical, 10)
        }
        .padding(.horizontal, 30)
        .padding(.top, 10)
    }
}

#Preview {
    ContentView()
}
