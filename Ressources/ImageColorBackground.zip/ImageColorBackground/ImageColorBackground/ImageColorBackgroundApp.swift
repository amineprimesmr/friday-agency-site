//
//  ImageColorBackgroundApp.swift
//  ImageColorBackground
//
//  Created by Balaji Venkatesh on 04/04/26.
//

import SwiftUI

@main
struct ImageColorBackgroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
