//
//  ContentView.swift
//  FTBar
//
//  Created by Balaji Venkatesh on 08/04/26.
//

import SwiftUI

struct ContentView: View {
    @State private var selection: String = "For You"
    @State private var searchText: String = ""
    @State private var isSearchExpanded: Bool = false
    @State private var isSearchActivated: Bool = false
    var body: some View {
        ScrollView(.vertical) {
            
        }
        .safeAreaInset(edge: .top, spacing: 0) {
            VStack(alignment: .leading, spacing: 15) {
                if !isSearchActivated {
                    HStack(spacing: 2) {
                        Image(systemName: "apple.logo")
                        Text("Fitness+")
                    }
                    .font(.largeTitle.bold())
                    .padding(.horizontal, 15)
                }
                
                /// Custom Tab bar
                CustomTabBar(
                    items: ["For You", "Explore", "Plans", "Library"],
                    selection: $selection,
                    searchText: $searchText,
                    isSearchExpanded: $isSearchExpanded
                ) { isKeyboardActive in
                    withAnimation(.snappy) {
                        isSearchActivated = isKeyboardActive
                    }
                }
            }
            .padding(.top, 15)
        }
        .background(Color.primary.opacity(0.07))
    }
}

#Preview {
    ContentView()
}
