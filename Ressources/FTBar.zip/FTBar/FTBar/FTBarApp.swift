//
//  FTBarApp.swift
//  FTBar
//
//  Created by Balaji Venkatesh on 08/04/26.
//

import SwiftUI

@main
struct FTBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
