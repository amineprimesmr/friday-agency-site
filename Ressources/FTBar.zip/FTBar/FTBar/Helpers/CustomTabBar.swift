//
//  CustomTabBar.swift
//  FTBar
//
//  Created by Balaji Venkatesh on 08/04/26.
//

import SwiftUI

struct CustomTabBar: View {
    var items: [String]
    var searchHint: String = "Workouts, Trainers, Music and More..."
    @Binding var selection: String
    @Binding var searchText: String
    @Binding var isSearchExpanded: Bool
    var onSearchActivated: (Bool) -> ()
    /// View Properties
    @Environment(\.colorScheme) private var colorScheme
    @State private var viewSize: CGSize = .zero
    @FocusState private var isKeyboardActive: Bool
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 12) {
                ForEach(items, id: \.self) { item in
                    ItemView(item)
                }
                
                ExpandableSearchBar()
            }
            .padding(.horizontal, 15)
            /// Making it center of the screen when the search bar is expanded!
            .visualEffect { [isSearchExpanded, viewSize] content, proxy in
                let rect = proxy.frame(in: .scrollView)
                let maxX = rect.maxX - viewSize.width
                
                return content
                    .offset(x: isSearchExpanded ? -maxX : 0)
            }
        }
        .frame(height: 50)
        .scrollDisabled(isSearchExpanded)
        .scrollIndicators(.hidden)
        .scrollClipDisabled()
        .animation(animation, value: selection)
        .animation(animation, value: isKeyboardActive)
        .onChange(of: isKeyboardActive) { oldValue, newValue in
            onSearchActivated(newValue)
        }
        .onGeometryChange(for: CGSize.self) {
            $0.size
        } action: { newValue in
            viewSize = newValue
        }
    }
    
    /// Item View
    @ViewBuilder
    private func ItemView(_ item: String) -> some View {
        let isSelected = selection == item
        let foregroundTint: Color = isSelected ? (colorScheme != .dark ? .white : .black) : .primary
        let backgroundTint: Color = isSelected ? (colorScheme == .dark ? .white : .black) : .clear
        
        let isLast = items.last == item && isSearchExpanded
        
        ZStack {
            if isLast {
                /// Minimise Button
                Image(systemName: "circle.grid.2x2.fill")
                    .frame(width: 60, height: 45)
                    .glassEffect(.regular.interactive(), in: .capsule)
                    .contentShape(.capsule)
                    .onTapGesture {
                        isKeyboardActive = false
                        withAnimation(animation) {
                            isSearchExpanded = false
                        }
                    }
                    .padding(.leading, 12)
            } else {
                Text(item)
                    .padding(.horizontal, 15)
                    .frame(height: 45)
                    .foregroundStyle(foregroundTint)
                    .background(backgroundTint, in: .capsule)
                    .glassEffect(.regular.interactive(!isSearchExpanded), in: .capsule)
                    .contentShape(.capsule)
                    .onTapGesture {
                        selection = item
                    }
                    .disabled(isSearchExpanded)
            }
        }
    }
    
    /// Expandable Search bar
    @ViewBuilder
    private func ExpandableSearchBar() -> some View {
        /// 102: 12 Spacing from main View, 60 From the Minimise Button & horizontal Padding 30
        /// 12+60+30 = 102
        let fitSearchBarWidth: CGFloat = viewSize.width - 102
        
        ZStack(alignment: .trailing) {
            HStack(spacing: 0) {
                Image(systemName: "magnifyingglass")
                    .font(.title3)
                    .frame(width: isSearchExpanded ? 40 : 60)
                
                if isSearchExpanded {
                    TextField(searchHint, text: $searchText)
                        .focused($isKeyboardActive)
                }
            }
            .padding(.leading, isSearchExpanded ? 5 : 0)
            .padding(.trailing, isSearchExpanded ? 15 : 0)
            .frame(height: 45)
            .clipShape(.capsule)
            .glassEffect(.regular.interactive(), in: .capsule)
            .contentShape(.capsule)
            .gesture(
                TapGesture(count: 1).onEnded { _ in
                    withAnimation(animation) {
                        isSearchExpanded = true
                    }
                },
                isEnabled: !isSearchExpanded
            )
            .zIndex(1)
            /// 45: Width + 12: Spacing = 57
            .padding(.trailing, isKeyboardActive ? 57 : 0)
            
            Image(systemName: "xmark")
                .frame(width: 45, height: 45)
                .glassEffect(.regular.interactive(), in: .circle)
                .contentShape(.circle)
                .onTapGesture {
                    isKeyboardActive = false
                }
                .opacity(isKeyboardActive ? 1 : 0)
                // Optional:
                //.offset(x: isKeyboardActive ? 0 : 70)
                .zIndex(0)
        }
        .frame(width: isSearchExpanded ? fitSearchBarWidth : nil)
    }
    
    /// Update the animation according to your needs!
    private let animation: Animation = .interpolatingSpring(duration: 0.3, bounce: 0, initialVelocity: 0)
}

#Preview {
    ContentView()
}
