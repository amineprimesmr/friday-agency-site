//
//  ContentView.swift
//  AppStoreScrollEffect
//
//  Created by Balaji Venkatesh on 14/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink("Apple Mail") {
                    DetailView()
                }
            }
            .navigationTitle("App Store")
        }
    }
}

struct DetailView: View {
    @State private var isHeaderChanged: Bool = false
    @State private var isDownloaded: Bool = false
    var body: some View {
        ScrollView(.vertical) {
            /// Dummy View Content (AKA App Store Product Page View)
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 10) {
                    Image(.logo)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .clipShape(.rect(cornerRadius: 25))
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Mail")
                            .font(.title3)
                            .fontWeight(.medium)
                        
                        Text("Productivity")
                            .font(.callout)
                            .foregroundStyle(.gray)
                        
                        Spacer(minLength: 0)
                        
                        ZStack {
                            if isDownloaded {
                                Button("Open") {
                                    isDownloaded.toggle()
                                }
                                .font(.callout)
                                .buttonStyle(.borderedProminent)
                                .buttonBorderShape(.capsule)
                            } else {
                                Button {
                                    isDownloaded.toggle()
                                } label: {
                                    Image(systemName: "icloud.and.arrow.down")
                                        .font(.title3)
                                        .fontWeight(.medium)
                                }
                            }
                        }
                        .animation(.easeInOut(duration: 0.2), value: isDownloaded)
                    }
                    .padding(.vertical, 5)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(15)
                .opacity(isHeaderChanged ? 0 : 1)
                
                Image(.content)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.bottom, 100)
            }
        }
        .appStoreStyleToolBar(triggerOffset: 110) {
            Button {
                
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .fontWeight(.medium)
            }
            .buttonStyle(iOS26ToolBarButtonStyle())
        } afterTrailingContent: {
            ZStack(alignment: .trailing) {
                Button {
                    isDownloaded.toggle()
                } label: {
                    Image(systemName: "icloud.and.arrow.down")
                        .fontWeight(.medium)
                }
                .buttonStyle(iOS26ToolBarButtonStyle())
                .opacity(isDownloaded ? 0 : 1)
                
                Button {
                    isDownloaded.toggle()
                } label: {
                    Text("Open")
                        .font(.callout)
                        .foregroundStyle(.white)
                        .fixedSize()
                        .frame(width: isDownloaded ? nil : 0)
                }
                .buttonStyle(iOS26ToolBarButtonStyle(isTinted: true))
                .opacity(isDownloaded ? 1 : 0)
            }
            .animation(.easeInOut(duration: 0.15), value: isDownloaded)
        } beforeCenterContent: {
//            Text("Mail")
//                .font(.callout)
//                .fontWeight(.semibold)
        } afterCenterContent: {
            Image(.logo)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: isiOS26 ? 35 : 30, height: isiOS26 ? 35 : 30)
                .clipShape(.rect(cornerRadius: isiOS26 ? 10 : 7))
        } onStatusChanged: { isChanged in
            withAnimation(.easeInOut(duration: 0.25)) {
                isHeaderChanged = isChanged
            }
        }
    }
    
    var isiOS26: Bool {
        if #available(iOS 26, *) {
            return true
        }
        return false
    }
}

struct iOS26ToolBarButtonStyle: ButtonStyle {
    var isTinted: Bool = false
    
    func makeBody(configuration: Configuration) -> some View {
        if #available(iOS 26, *) {
            configuration.label
                .frame(width: isTinted ? nil : 48, height: isTinted ? 36 : 48)
                .padding(.horizontal, isTinted ? 15 : 0)
                .contentShape(.rect)
                .glassEffect(.regular.tint(.blue.opacity(isTinted ? 1 : 0)).interactive(), in: .capsule)
        } else {
            configuration.label
                .foregroundStyle(.blue)
                .frame(height: isTinted ? 30 : nil)
                .padding(.horizontal, isTinted ? 15 : 0)
                .contentShape(.rect)
                .background(.blue.opacity(isTinted ? 1 : 0), in: .capsule)
        }
    }
}

#Preview {
    ContentView()
}
