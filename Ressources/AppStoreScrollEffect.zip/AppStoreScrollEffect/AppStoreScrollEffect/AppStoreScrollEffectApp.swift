//
//  AppStoreScrollEffectApp.swift
//  AppStoreScrollEffect
//
//  Created by Balaji Venkatesh on 14/12/25.
//

import SwiftUI

@main
struct AppStoreScrollEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
