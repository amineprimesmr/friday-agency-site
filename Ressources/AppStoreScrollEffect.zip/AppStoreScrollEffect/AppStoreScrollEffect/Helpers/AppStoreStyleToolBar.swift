//
//  AppStoreStyleToolBar.swift
//  AppStoreScrollEffect
//
//  Created by Balaji Venkatesh on 14/12/25.
//

import SwiftUI

extension View {
    @ViewBuilder
    func appStoreStyleToolBar<T1: View, T2: View, C1: View, C2: View>(
        triggerOffset: CGFloat,
        @ViewBuilder beforeTrailingContent: @escaping () -> T1,
        @ViewBuilder afterTrailingContent: @escaping () -> T2,
        @ViewBuilder beforeCenterContent: @escaping () -> C1,
        @ViewBuilder afterCenterContent: @escaping () -> C2,
        onStatusChanged: @escaping (_ isChanged: Bool) -> () = { _ in }
    ) -> some View {
        self
            .navigationBarTitleDisplayMode(.inline)
            .navigationTitle("")
            .modifier(
                AppStoreStyleToolBarHelper(
                    triggerOffset: triggerOffset,
                    beforeTrailingContent: beforeTrailingContent,
                    afterTrailingContent: afterTrailingContent,
                    beforeCenterContent: beforeCenterContent,
                    afterCenterContent: afterCenterContent,
                    onStatusChanged: onStatusChanged
                )
            )
    }
}

/// Helper View Modifier
fileprivate struct AppStoreStyleToolBarHelper<T1: View, T2: View, C1: View, C2: View>: ViewModifier {
    var triggerOffset: CGFloat
    @ViewBuilder var beforeTrailingContent: T1
    @ViewBuilder var afterTrailingContent: T2
    @ViewBuilder var beforeCenterContent: C1
    @ViewBuilder var afterCenterContent: C2
    var onStatusChanged: (Bool) -> () = { _ in }
    /// View Properties
    @State private var isChanged: Bool = false
    func body(content: Content) -> some View {
        content
            /// Fetching Scroll Offset and checking with trigger offset, to determine whether to show after contents on the tool bar!
            .onScrollGeometryChange(for: CGFloat.self) {
                $0.contentOffset.y + $0.contentInsets.top
            } action: { oldValue, newValue in
                let progress = max(min(newValue / triggerOffset, 1), 0)
                /// You can change this condition according to your needs!
                withAnimation(.easeInOut(duration: 0.25)) {
                    isChanged = progress > 0.99
                }
                
                onStatusChanged(isChanged)
            }
            .toolbar {
                /// Trailing Content
                ToolbarItem(placement: .topBarTrailing) {
                    ZStack(alignment: .trailing) {
                        beforeTrailingContent
                            .hideWithScale(isChanged)
                        
                        afterTrailingContent
                            .hideWithOffset(!isChanged)
                    }
                }
                .backportedSharedVisibility(.hidden)
                
                /// Center Content
                ToolbarItem(placement: .title) {
                    ZStack(alignment: .center) {
                        beforeCenterContent
                            .hideWithScale(isChanged)
                        
                        afterCenterContent
                            .hideWithOffset(!isChanged)
                    }
                    /// Making sure that the title bar content don't exceed certain height limit!
                    .frame(maxHeight: 35)
                }
                .backportedSharedVisibility(.hidden)
            }
    }
}

/// Helper ToolBar Extensions
fileprivate extension ToolbarItem {
    @ToolbarContentBuilder
    func backportedSharedVisibility(_ visibility: Visibility) -> some ToolbarContent {
        if #available(iOS 26, *) {
            self
                .sharedBackgroundVisibility(visibility)
        } else {
            self
        }
    }
}

/// Helper Extensions
fileprivate extension View {
    /// Hide with offset and scale effect modifiers!
    @ViewBuilder
    func hideWithOffset(_ isHidden: Bool) -> some View {
        self
            .offset(y: isHidden ? 10 : 0)
            .opacity(isHidden ? 0 : 1)
    }
    
    @ViewBuilder
    func hideWithScale(_ isHidden: Bool) -> some View {
        self
            .scaleEffect(isHidden ? 0.5 : 1)
            .opacity(isHidden ? 0 : 1)
    }
}
