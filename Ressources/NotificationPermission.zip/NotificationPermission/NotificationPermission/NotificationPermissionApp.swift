//
//  NotificationPermissionApp.swift
//  NotificationPermission
//
//  Created by Balaji Venkatesh on 05/09/25.
//

import SwiftUI

@main
struct NotificationPermissionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
