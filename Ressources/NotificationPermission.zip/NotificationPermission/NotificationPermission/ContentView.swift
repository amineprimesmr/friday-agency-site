//
//  ContentView.swift
//  NotificationPermission
//
//  Created by Balaji Venkatesh on 05/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var askPermission: Bool = false
    var body: some View {
        let config = NotificationOnBoardingConfig(
            title: "Stay Connected with\nPush Notifications",
            content: "We will send you push notifications to keep you updated on the latest news and updates.",
            notificationTitle: "Hello iJustine!",
            notificationContent: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            primaryButtonTitle: "Continue",
            secondaryButtonTitle: "Ask Me Later"
        )
        
        NavigationStack {
            List {
                Section("Usage") {
                    Text(
                    """
                    NotificationOnBoarding(config) {
                        // Logo
                    } onPermissionChange: {
                        
                    } onPrimaryButtonTap: {
                        
                    } onSecondaryButtonTap: {
                        
                    }
                    """
                    )
                    .font(.callout)
                    .monospaced()
                }
                
                Button("Show Notification Onboarding") {
                    askPermission.toggle()
                }
            }
            .navigationTitle("Notification's")
        }
        .fullScreenCover(isPresented: $askPermission) {
            NotificationOnBoarding(config: config) {
                /// Your App Logo!
                Image(systemName: "applelogo")
                    .font(.title2)
                    .foregroundStyle(.background)
                    .frame(width: 40, height: 40)
                    .background(.primary)
                    .clipShape(.rect(cornerRadius: 12))
            } onPermissionChange: { isApproved in
                print(isApproved)
            } onPrimaryButtonTap: {
                askPermission = false
            } onSecondaryButtonTap: {
                askPermission = false
            }
        }
    }
}

#Preview {
    ContentView()
}
