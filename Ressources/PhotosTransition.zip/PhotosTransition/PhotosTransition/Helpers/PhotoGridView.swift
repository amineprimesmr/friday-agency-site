//
//  PhotoGridView.swift
//  PhotosTransition
//
//  Created by Balaji Venkatesh on 04/03/26.
//

import SwiftUI

protocol PhotoProtocol: Hashable {
    var id: String { get }
}

fileprivate struct PhotoHeroEffectConfig<Element: PhotoProtocol> {
    var selectedItem: Element?
    var sourceLocation: CGRect = .zero
    var soruceScrollPosition: ScrollPosition = .init()
    var showFullScreenCover: Bool = false
}

struct PhotoGridView<Data: RandomAccessCollection, GridItem: View, Detail: View, Overlay: View>: View where Data.Element: PhotoProtocol {
    var spacing: CGFloat = 5
    var gridCount: Int = 3
    var gridItemHeight: CGFloat = 120
    var data: Data
    @ViewBuilder var gridItem: (Data.Element) -> GridItem
    @ViewBuilder var detail: (Data.Element, Bool, CGSize, @escaping () -> ()) -> Detail
    @ViewBuilder var overlay: (Data.Element?, Bool, CGSize, @escaping () -> ()) -> Overlay
    var onSelectionChanged: (Data.Element?) -> () = { _ in }
    /// View Properties
    @State private var config: PhotoHeroEffectConfig<Data.Element> = .init()
    var body: some View {
        let gridItems = Array(repeating: SwiftUI.GridItem(spacing: spacing), count: gridCount)
        
        ScrollView(.vertical) {
            LazyVGrid(columns: gridItems, spacing: spacing) {
                ForEach(data, id: \.id) { item in
                    Rectangle()
                        .foregroundStyle(.clear)
                        .overlay {
                            GeometryReader {
                                let rect = $0.frame(in: .global)
                                let updatedRect: CGRect? = config.selectedItem == item ? rect : nil
                                
                                gridItem(item)
                                    /// Hiding the source view when the hero effect is enabled
                                    .opacity(config.selectedItem == item ? 0 : 1)
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .contentShape(.rect)
                                    .onTapGesture {
                                        /// Storing info and opening full screen hero view
                                        config.selectedItem = item
                                        config.sourceLocation = rect
                                        /// Opening Full screen cover without animation
                                        withoutAnimation {
                                            config.showFullScreenCover = true
                                        }
                                    }
                                    /// Let's say when we change the selected on hero view by interacting with the page view, then we need to update the source location right?
                                    .onChange(of: updatedRect) { oldValue, newValue in
                                        if let newValue {
                                            config.sourceLocation = newValue
                                        }
                                    }
                            }
                        }
                        .frame(height: gridItemHeight)
                        .clipped()
                        .contentShape(.rect)
                }
            }
            .scrollTargetLayout()
        }
        .scrollPosition($config.soruceScrollPosition)
        .fullScreenCover(isPresented: $config.showFullScreenCover) {
            config.selectedItem = nil
        } content: {
            DetailPhotosView(config: $config, data: data, detail: detail, overlay: overlay)
        }
        /// Publishing selected item changes and also updating the source scroll view position when the item is changed from the hero detail view!
        .onChange(of: config.selectedItem) { oldValue, newValue in
            if let newValue, oldValue != nil {
                /// Not accounting the first initial change
                config.soruceScrollPosition.scrollTo(id: newValue.id)
            }
            
            onSelectionChanged(newValue)
        }
    }
}

fileprivate struct DetailPhotosView<Data: RandomAccessCollection, Detail: View, Overlay: View>: View where Data.Element: PhotoProtocol {
    @Binding var config: PhotoHeroEffectConfig<Data.Element>
    var data: Data
    @ViewBuilder var detail: (Data.Element, Bool, CGSize, @escaping () -> ()) -> Detail
    @ViewBuilder var overlay: (Data.Element?, Bool, CGSize, @escaping () -> ()) -> Overlay
    /// View Properties
    @State private var isExpanded: Bool = false
    @State private var viewSize: CGSize = .zero
    @State private var safeArea: EdgeInsets = .init()
    @State private var dragOffset: CGSize = .zero
    var body: some View {
        /// Using Tab View rather than scrollview!
        TabView(selection: $config.selectedItem) {
            ForEach(data, id: \.id) { item in
                let sourceFrame = config.sourceLocation
                
                detail(item, isExpanded, dragOffset, dismiss)
                    .frame(
                        width: isExpanded ? viewSize.width : sourceFrame.width,
                        height: isExpanded ? viewSize.height : sourceFrame.height,
                    )
                    .clipped()
                    .offset(
                        x: isExpanded ? 0 : sourceFrame.minX,
                        y: isExpanded ? 0 : sourceFrame.minY
                    )
                    .offset(dragOffset)
                    /// Since the view coordinate system starts at top left
                    .frame(
                        maxWidth: .infinity,
                        maxHeight: .infinity,
                        alignment: isExpanded ? .center : .topLeading
                    )
                    .tag(item)
                    .ignoresSafeArea()
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .ignoresSafeArea()
        .contentShape(.rect)
        .gesture(
            PanGesture { gesture in
                let state = gesture.state
                let translation = gesture.translation(in: gesture.view)
                
                if state == .began || state == .changed {
                    dragOffset = .init(width: translation.x, height: translation.y)
                } else {
                    if dragOffset.height > 50 {
                        dismiss()
                    } else {
                        withAnimation(animation.speed(1.2)) {
                            dragOffset = .zero
                        }
                    }
                }
            }
        )
        .overlay {
            overlay(config.selectedItem, isExpanded, dragOffset, dismiss)
                .compositingGroup()
                .opacity(interactiveOpacity)
                .opacity(isExpanded ? 1 : 0)
        }
        .presentationBackground {
            Rectangle()
                .fill(.black)
                .opacity(interactiveOpacity)
                .opacity(isExpanded ? 1 : 0)
        }
        .allowsHitTesting(isExpanded)
        /// Others
        .onGeometryChange(for: CGSize.self, of: {
            $0.size
        }, action: { newValue in
            viewSize = newValue
        })
        .onGeometryChange(for: EdgeInsets.self, of: {
            $0.safeAreaInsets
        }, action: { newValue in
            safeArea = newValue
        })
        .task {
            guard !isExpanded else { return }
            withAnimation(animation) {
                isExpanded = true
            }
        }
    }
    
    func dismiss() {
        Task {
            withAnimation(animation.speed(1.2)) {
                dragOffset = .zero
                isExpanded = false
            }
            
            try? await Task.sleep(for: .seconds(0.35))
            withoutAnimation {
                config.showFullScreenCover = false
            }
        }
    }
    
    var animation: Animation {
        .interpolatingSpring(duration: 0.3, bounce: 0, initialVelocity: 0)
    }
    
    /// Fadeout opacity for interactive gesture
    var interactiveOpacity: CGFloat {
        let opacityY = abs(dragOffset.height) / (viewSize.height * 0.3)
        return isExpanded ? (1 - opacityY) : 0
    }
}

fileprivate struct PanGesture: UIGestureRecognizerRepresentable {
    var handle: (UIPanGestureRecognizer) -> ()
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let gesture = UIPanGestureRecognizer()
        gesture.minimumNumberOfTouches = 1
        gesture.maximumNumberOfTouches = 1
        gesture.delegate = context.coordinator
        return gesture
    }
    
    func updateUIGestureRecognizer(_ recognizer: UIPanGestureRecognizer, context: Context) {
        
    }
    
    func handleUIGestureRecognizerAction(_ recognizer: UIPanGestureRecognizer, context: Context) {
        handle(recognizer)
    }
    
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator {
        Coordinator()
    }
    
    class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
            if let scrollView = otherGestureRecognizer.view as? UIScrollView {
                let contentOffset = scrollView.contentOffset
                return contentOffset.y <= 0
            }
            
            return false
        }
        
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let panGesture = gestureRecognizer as? UIPanGestureRecognizer else {
                return false
            }

            let velocity = panGesture.velocity(in: panGesture.view)

            return velocity.y > abs(velocity.x)
        }
    }
}

fileprivate extension View {
    func withoutAnimation(_ result: @escaping () -> ()) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction) {
            result()
        }
    }
}

#Preview {
    ContentView()
}
