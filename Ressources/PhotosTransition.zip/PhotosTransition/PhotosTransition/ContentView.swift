//
//  ContentView.swift
//  PhotosTransition
//
//  Created by Balaji Venkatesh on 04/03/26.
//

import SwiftUI

/// Dummy Model
struct Item: Identifiable, PhotoProtocol {
    var id: String = UUID().uuidString
    var title: String
    var image: UIImage?
}
/// Image Links
/// https://www.pexels.com/photo/hot-air-balloons-flying-in-cappadocia-at-sunrise-18873058/
/// https://www.pexels.com/photo/a-butterfly-on-a-flower-20672997/
/// https://www.pexels.com/photo/classic-blue-coupe-die-cast-model-1037995/
/// https://www.pexels.com/photo/pink-black-and-yellow-abstract-painting-2911519/
/// https://www.pexels.com/photo/light-blue-gradient-background-4040654/

var sampleItems: [Item] = [
    .init(title: "The Lake", image: .pic7),
    .init(title: "Butterfly", image: .pic1),
    .init(title: "Illustration", image: .pic2),
    .init(title: "A Car", image: .pic4),
    .init(title: "Shades", image: .pic3),
    .init(title: "iPhone", image: .pic1),
    .init(title: "Hot Air Balloon", image: .pic7),
    .init(title: "iPadOS 26", image: .pic2),
]

struct ContentView: View {
    @State private var imageMode: ContentMode = .fit
    var body: some View {
        TabView {
            Tab.init("Library", systemImage: "photo.on.rectangle") {
                NavigationStack {
                    PhotoGridView(data: sampleItems) { item in
                        ImageView(item, mode: imageMode)
                            .animation(.smooth(duration: 0.25, extraBounce: 0), value: imageMode)
                    } detail: { item, isExpanded, dragOffset, dismiss in
                        VStack(spacing: 0) {
                            if isExpanded {
                                Rectangle()
                                    .foregroundStyle(.clear)
                                    .frame(height: 80)
                            }
                            
                            ImageView(item, mode: isExpanded ? .fit : imageMode)
                            
                            if isExpanded {
                                Rectangle()
                                    .foregroundStyle(.clear)
                                    .frame(height: 50)
                            }
                        }
                    } overlay: { selectedItem, isExpanded, dragOffset, dismiss in
                        if #available(iOS 26, *) {
                            OverlayActionView(
                                selectedItem: selectedItem,
                                dragOffset: dragOffset,
                                dismiss: dismiss
                            )
                        }
                    } onSelectionChanged: { item in
                        
                    }
                    .safeAreaPadding(15)
                    .scrollIndicators(.hidden)
                    .navigationTitle("Library")
                    .toolbarTitleDisplayMode(.inlineLarge)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Menu("Sort", systemImage: "line.3.horizontal.decrease") {
                                Picker("", selection: $imageMode) {
                                    Text("Fit")
                                        .tag(ContentMode.fit)
                                    
                                    Text("Fill")
                                        .tag(ContentMode.fill)
                                }
                            }
                        }
                    }
                }
            }
            
            Tab.init("Collections", systemImage: "square.stack.fill") {
                
            }
            
            Tab.init(role: .search) {
                
            }
        }
    }
    
    @ViewBuilder
    func ImageView(_ item: Item, mode: ContentMode) -> some View {
        Rectangle()
            .foregroundStyle(.clear)
            .overlay {
                if let image = item.image {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: mode)
                }
            }
    }
    
    @available(iOS 26, *)
    @ViewBuilder
    func OverlayActionView(
        selectedItem: Item?,
        dragOffset: CGSize,
        dismiss: @escaping () -> ()
    ) -> some View {
        let interactiveOpacity: CGFloat = 1 - min(abs(dragOffset.height / 30), 1)
        
        VStack {
            /// Top Actions
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.title3)
                        .frame(width: 20, height: 30)
                }
                .buttonStyle(.glass)
                
                Spacer(minLength: 0)
                
                Button {
                    
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.title3)
                        .frame(width: 20, height: 30)
                }
                .buttonStyle(.glass)
            }
            .overlay {
                if let title = selectedItem?.title {
                    Text(title)
                        .font(.callout)
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .padding(.horizontal, 15)
                        .padding(.vertical, 10)
                        .clipShape(.capsule)
                        .glassEffect(.regular, in: .capsule)
                        .contentTransition(.numericText())
                        .animation(.easeInOut, value: title)
                        .frame(maxWidth: .infinity)
                }
            }
            
            Spacer(minLength: 0)
            
            /// Bottom Actions
            HStack {
                Button {
                    
                } label: {
                    Image(systemName: "square.and.arrow.up.fill")
                        .font(.title3)
                        .frame(width: 20, height: 30)
                }
                .buttonStyle(.glass)
                
                HStack(spacing: 15) {
                    Button {
                        
                    } label: {
                        Image(systemName: "suit.heart")
                            .font(.title3)
                            .padding(10)
                    }
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "info.circle")
                            .font(.title3)
                            .padding(10)
                    }
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "slider.horizontal.3")
                            .font(.title3)
                            .padding(10)
                    }
                }
                .foregroundStyle(Color.primary)
                .padding(.horizontal, 10)
                .glassEffect(.regular.interactive(), in: .capsule)
                .frame(maxWidth: .infinity)
                
                Button {
                    
                } label: {
                    Image(systemName: "trash")
                        .font(.title3)
                        .frame(width: 20, height: 30)
                }
                .buttonStyle(.glass)
            }
        }
        .padding(.horizontal, 15)
        .compositingGroup()
        .opacity(interactiveOpacity)
        .environment(\.colorScheme, .dark)
    }
}

#Preview {
    ContentView()
}
