//
//  PhotosTransitionApp.swift
//  PhotosTransition
//
//  Created by Balaji Venkatesh on 04/03/26.
//

import SwiftUI

@main
struct PhotosTransitionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
