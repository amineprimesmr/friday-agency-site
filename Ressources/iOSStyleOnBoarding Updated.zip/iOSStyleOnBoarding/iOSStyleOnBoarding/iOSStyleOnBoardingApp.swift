//
//  iOSStyleOnBoardingApp.swift
//  iOSStyleOnBoarding
//
//  Created by Balaji Venkatesh on 19/02/26.
//

import SwiftUI

@main
struct iOSStyleOnBoardingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
