//
//  Custom_SplashScreenApp.swift
//  Custom_SplashScreen
//
//  Created by Balaji Venkatesh on 15/11/25.
//

import SwiftUI

@main
struct Custom_SplashScreenApp: App {
    var body: some Scene {
        LaunchScreen {
            Image(.launchScreenLogo)
        } rootContent: {
            ContentView()
        }
    }
}
