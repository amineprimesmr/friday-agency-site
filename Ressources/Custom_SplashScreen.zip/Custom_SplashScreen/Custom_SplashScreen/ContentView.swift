//
//  ContentView.swift
//  Custom_SplashScreen
//
//  Created by Balaji Venkatesh on 15/11/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("Usage: Custom WindowGroup") {
                    Text(
                    """
                    **LaunchScreen** {
                      // Logo
                    } **rootContent:** {
                        
                    }
                    """
                    )
                    .monospaced()
                }
            }
            .navigationTitle("Splash Screen")
        }
    }
}

#Preview {
    ContentView()
}
