//
//  BorderBeamApp.swift
//  BorderBeam
//
//  Created by Balaji Venkatesh on 30/04/26.
//

import SwiftUI

@main
struct BorderBeamApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
