//
//  ContentView.swift
//  BorderBeam
//
//  Created by Balaji Venkatesh on 30/04/26.
//

import SwiftUI

struct ContentView: View {
    @State private var enableMainBorder: Bool = true
    @State private var showColors: Bool = true
    @State private var enableButtonBorder: Bool = false
    var body: some View {
        NavigationStack {
            VStack(spacing: 15) {
                VStack(alignment: .leading, spacing: 15) {
                    Text("USAGE:")
                        .fontWeight(.semibold)
                    
                    Text(
                    """
                    .borderBeam(
                        border,
                        beam,
                        beamBlur,
                        cornerRadius,
                        isEnabled
                    )
                    """
                    )
                    .kerning(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(15)
                    .background(.fill.tertiary, in: .rect(cornerRadius: 20))
                    
                    Text("DEMO:")
                        .fontWeight(.semibold)
                    
                    VStack(spacing: 10) {
                        Toggle("Show Colors", isOn: $showColors)
                        Toggle("Enable Main Border", isOn: $enableMainBorder)
                        Toggle("Enable Button Border", isOn: $enableButtonBorder)
                    }
                    .padding(.bottom, 30)
                }
                .monospaced()
                
                CustomBottomBar()
                    .borderBeam(
                        border: .white,
                        beam: showColors ? [.green, .blue, .pink, .orange, .indigo] : [],
                        beamBlur: 15,
                        cornerRadius: 20,
                        isEnabled: enableMainBorder
                    )
                    .background(.gray.opacity(0.1), in: .rect(cornerRadius: 20))
                
                Spacer(minLength: 0)
            }
            .padding(15)
            .navigationTitle("Border Effect")
            .toolbarTitleDisplayMode(.inlineLarge)
        }
        .preferredColorScheme(.dark)
    }
    
    @ViewBuilder
    func CustomBottomBar() -> some View {
        VStack(alignment: .leading, spacing: 25) {
            TextField("Ask Anything...", text: .constant(""))
                .padding(.top, 8)
            
            HStack(spacing: 20) {
                Button {
                    
                } label: {
                    Text("Name/Model Name")
                        .font(.caption)
                        .foregroundStyle(Color.primary.opacity(0.8))
                        .padding(.vertical, 8)
                        .padding(.horizontal, 15)
                        .background(.fill, in: .capsule)
                }

                Spacer(minLength: 0)
                
                Group {
                    Button {
                        
                    } label: {
                        Image(systemName: "plus")
                    }
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "cloud")
                    }
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "mic")
                    }
                    
                    CustomButton()
                }
                .foregroundStyle(Color.primary)
            }
        }
        .padding(15)
    }
    
    @ViewBuilder
    func CustomButton() -> some View {
        Button {
            
        } label: {
            Image(systemName: "arrow.up")
                .foregroundStyle(Color.primary)
                .frame(width: 35, height: 35)
                .borderBeam(
                    border: .white,
                    beam: [.green, .blue, .pink, .orange, .indigo],
                    beamBlur: 15,
                    cornerRadius: 20,
                    isEnabled: enableButtonBorder
                )
                .background(.background, in: .circle)
        }
    }
}

#Preview {
    ContentView()
}
