//
//  PayWallEffectApp.swift
//  PayWallEffect
//
//  Created by Balaji Venkatesh on 04/02/26.
//

import SwiftUI

@main
struct PayWallEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
