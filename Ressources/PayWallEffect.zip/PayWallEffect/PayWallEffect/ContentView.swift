//
//  ContentView.swift
//  PayWallEffect
//
//  Created by Balaji Venkatesh on 04/02/26.
//

import SwiftUI

struct ContentView: View {
    @State private var showPayWall: Bool = false
    @State private var safeArea: EdgeInsets = .init()
    var body: some View {
        NavigationStack {
            List {
                Button("Show Sheet") {
                    showPayWall.toggle()
                }
            }
            .navigationTitle("UI Animation")
            .sheet(isPresented: $showPayWall) {
                PaywallView(safeArea: $safeArea)
            }
        }
        .onGeometryChange(for: EdgeInsets.self) {
            $0.safeAreaInsets
        } action: { newValue in
            safeArea = newValue
        }
    }
}

struct PaywallView: View {
    @Binding var safeArea: EdgeInsets
    @Environment(\.colorScheme) private var colorScheme
    var body: some View {
        let sheetHeight: CGFloat = 540 - (isiOS26 ? safeArea.bottom : 0)
        
        VStack(spacing: 10) {
            let symbols: [String] = ["photo", "square.arrowtriangle.4.outward", "arrow.up.and.down.and.arrow.left.and.right", "square.and.arrow.up.fill"]
            
            Paywall3DEffect(symbols: symbols, symbolFont: .title, tint: .primary)
                .frame(height: 300)
            
            Text("Welcome to Awesome App!")
                .font(.title2.bold())
            
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard since the 1500s.")
                .font(.system(size: 15))
                .lineLimit(3)
            
            Spacer(minLength: 5)
            
            VStack(spacing: 6) {
                Text("14 days free, then $0.99/month")
                    .font(.caption2)
                
                Button {
                    
                } label: {
                    Text("Continue")
                        .fontWeight(.medium)
                        .frame(maxWidth: .infinity)
                        .foregroundStyle(colorScheme != .dark ? .white : .black)
                        .padding(.vertical, 10)
                        .background(colorScheme == .dark ? .white : .black, in: .capsule)
                }

                Button("Privacy Policy & Terms") {
                    
                }
                .font(.caption2)
                .foregroundStyle(.gray)
                .padding(.top, 5)
            }
            .padding(.horizontal, 30)
        }
        .padding([.horizontal], 15)
        /// Non SafeArea iPhones such as Touch ID one dont have space at bottom so for those giving 10 padding!
        .padding(.bottom, isiOS26 ? 15 : (safeArea.bottom == 0 ? 10 : 0))
        .ignoresSafeArea(.all, edges: isiOS26 ? .all : [])
        .presentationDetents([.height(sheetHeight)])
    }
    
    var isiOS26: Bool {
        if #available(iOS 26, *) {
            return true
        }
        
        return false
    }
}

#Preview {
    ContentView()
}
