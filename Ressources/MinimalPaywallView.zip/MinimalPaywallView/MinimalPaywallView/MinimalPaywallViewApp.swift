//
//  MinimalPaywallViewApp.swift
//  MinimalPaywallView
//
//  Created by Balaji Venkatesh on 06/10/25.
//

import SwiftUI

@main
struct MinimalPaywallViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
