//
//  ContentView.swift
//  MinimalPaywallView
//
//  Created by Balaji Venkatesh on 06/10/25.
//

import SwiftUI
import StoreKit

struct ContentView: View {
    @State private var isCompact: Bool = false
    @State private var showPaywall: Bool = false
    var body: some View {
        NavigationStack {
            List {
                Toggle("Compact Pricing View", isOn: $isCompact)
                Button("Show Paywall") {
                    showPaywall.toggle()
                }
            }
            .navigationTitle("Paywall")
        }
        .sheet(isPresented: $showPaywall) {
            PaywallView(isCompact: isCompact, ids: Self.productIDs, points: Self.points) {
                AppInformationView()
            } links: {
                LinksView()
            } loadingView: {
                /// Your Custom Loading View Here
                ProgressView()
            }
            .tint(Color.primary)
            .interactiveDismissDisabled()
            .onInAppPurchaseStart { product in
                print("Purchasing \(product.displayName)")
            }
            .onInAppPurchaseCompletion { product, result in
                print(result)
            }
            .subscriptionStatusTask(for: "2C542CDC") { _ in
                print("Check for subscription status")
            }
        }
    }
    
    /// App Information View
    @ViewBuilder
    func AppInformationView() -> some View {
        VStack(spacing: 15) {
            VStack(alignment: .trailing, spacing: 0) {
                Text("App Name")
                    .font(.title.bold())
                
                Text("Premium")
                    .font(.caption.bold())
                    .foregroundStyle(.background)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.primary, in: .capsule)
                    .offset(x: 5)
            }
            .lineLimit(1)
            .padding(.top, 10)
            
            Image(systemName: "apple.logo")
                .font(.system(size: 60))
                .foregroundStyle(.background)
                .frame(width: 100, height: 100)
                .background(Color.primary, in: .rect(cornerRadius: 25))
                .padding(.vertical, 25)
        }
    }
    
    /// App Links View
    @ViewBuilder
    func LinksView() -> some View {
        HStack(spacing: 5) {
            Link("Terms of Service", destination: URL(string: "https://apple.com")!)
            
            Text("&")
            
            Link("Privacy Policy", destination: URL(string: "https://apple.com")!)
        }
        .font(.caption)
        .foregroundStyle(.gray)
    }
    
    /// Your IAP IDs
    static var productIDs: [String] {
        return ["pro_weekly", "pro_monthly", "pro_yearly"]
    }
    
    /// Your IAP Points
    static var points: [PaywallPoint] = [
        .init(symbol: "star", content: "High-quality premium templates"),
        .init(symbol: "arrow.up.circle", content: "Download unlimited PNGs"),
        .init(symbol: "paintbrush", content: "Exclusive customizable designs"),
        .init(symbol: "lock.open", content: "Unlock everything with premium")
    ]
}

#Preview {
    ContentView()
}
